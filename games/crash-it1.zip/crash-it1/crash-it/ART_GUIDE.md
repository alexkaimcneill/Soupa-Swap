# Editing Crash It

Same system as the other games: art in `sprites.png` (512x400), positions in `sprites.json`, no code editing. `sprites_marked.png` is the box map.

## Spritesheet layout

| Sprite | Position (x, y) | Size | Notes |
|---|---|---|---|
| car_red | 0, 0 | 60 x 40 | Player 1 car. Tanuki driver sits in the cockpit; the head above the roof is the weak point. |
| car_blue | 70, 0 | 60 x 40 | Player 2 car (drawn facing same way; game flips it). |
| wheel | 140, 0 | 16 x 16 | Spare wheel sprite (decorative / future use). |
| head_red | 166, 0 | 20 x 20 | P1 tanuki head, used for the scoreboard. |
| head_blue | 196, 0 | 20 x 20 | P2 tanuki head, scoreboard. |
| title | 0, 60 | 460 x 90 | CRASH IT logo. |

The arena (walls, floor, platforms, background) is drawn in code, not from sprites — see `build_arena()` and `draw_arena()` in main.py if you want to change the map shape.

## Rules

Two cars in an enclosed arena. Each car is driven by a tanuki whose head pokes above the roof. Ram, shove, and flip the other player so their HEAD touches a wall, the floor, the ceiling, a platform, or your car. When it does, you score. Protect your own head (stay upright!). First to `wins_to_match` wins.

## Controls (keyboard)

- Player 1: W = gas, S = reverse, A/D = turn (torque)
- Player 2: Up = gas, Down = reverse, Left/Right = turn
- Two USB gamepads also work (stick = turn, up/A = gas)
- Space/A = start / continue, Esc/Start = quit

## Gameplay tuning (sprites.json)

- `engine_force` / `reverse_force` - drive power
- `torque` - how hard turning spins the car (this is what lets you flip the opponent)
- `max_angular` - spin speed cap
- `gravity` - fall speed
- `linear_damp` / `angular_damp` - how quickly motion/spin bleeds off (friction feel)
- `bounce` - collision restitution (higher = bouncier crashes)
- `wins_to_match` - rounds needed to win the match

## Testing on desktop

GAME_WINDOWED=1 python3 main.py   (ESC quits)
Windows: set GAME_WINDOWED=1, then py -3.12 main.py

## Regenerating default art

python3 build_sheet.py rebuilds sprites.png, sprites.json, sprites_marked.png, icon.png.
