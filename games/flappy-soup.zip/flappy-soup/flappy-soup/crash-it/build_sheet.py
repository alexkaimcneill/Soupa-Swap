from PIL import Image, ImageDraw, ImageFont, ImageFilter
import numpy as np
import json

SHEET_W, SHEET_H = 512, 400

LAYOUT = {
    "car_red": {"x": 0, "y": 0, "w": 60, "h": 40},
    "car_blue": {"x": 70, "y": 0, "w": 60, "h": 40},
    "wheel": {"x": 140, "y": 0, "w": 16, "h": 16},
    "head_red": {"x": 166, "y": 0, "w": 20, "h": 20},
    "head_blue": {"x": 196, "y": 0, "w": 20, "h": 20},
    "title": {"x": 0, "y": 60, "w": 460, "h": 90},
}

boxes = []
for name, s in LAYOUT.items():
    boxes.append((name, s["x"], s["y"], s["x"] + s["w"], s["y"] + s["h"]))
for i in range(len(boxes)):
    for j in range(i + 1, len(boxes)):
        n1, a, b, c, e = boxes[i]
        n2, f, g, h, k = boxes[j]
        assert not (a < h and f < c and b < k and g < e), f"OVERLAP {n1}/{n2}"
for name, x1, y1, x2, y2 in boxes:
    assert x2 <= SHEET_W and y2 <= SHEET_H, f"OOB {name}"
print("layout verified")

sheet = Image.new("RGBA", (SHEET_W, SHEET_H), (0, 0, 0, 0))
d = ImageDraw.Draw(sheet)

CREAM = (244, 232, 214)
CREAM_D = (216, 198, 172)
BROWN = (120, 92, 76)
MASK = (86, 66, 58)


def tanuki_head(ox, oy, w=20, h=20):
    d.ellipse([ox + 2, oy + 2, ox + w - 2, oy + h - 2], fill=CREAM, outline=MASK)
    d.polygon([(ox + 3, oy + 4), (ox + 1, oy - 2), (ox + 7, oy + 2)], fill=CREAM_D, outline=MASK)
    d.polygon([(ox + w - 3, oy + 4), (ox + w - 1, oy - 2), (ox + w - 7, oy + 2)], fill=BROWN, outline=MASK)
    d.ellipse([ox + 4, oy + 7, ox + 9, oy + 12], fill=MASK)
    d.ellipse([ox + w - 9, oy + 7, ox + w - 4, oy + 12], fill=MASK)
    d.ellipse([ox + 5, oy + 8, ox + 7, oy + 10], fill=(255, 255, 255))
    d.ellipse([ox + w - 8, oy + 8, ox + w - 6, oy + 10], fill=(255, 255, 255))
    d.ellipse([ox + w // 2 - 2, oy + 12, ox + w // 2 + 2, oy + 16], fill=(70, 52, 46))


def draw_car(ox, oy, body, body_d, trim):
    d.rectangle([ox + 6, oy + 22, ox + 54, oy + 36], fill=body, outline=(30, 30, 40))
    d.polygon([(ox + 12, oy + 22), (ox + 20, oy + 10), (ox + 42, oy + 10), (ox + 48, oy + 22)],
              fill=body_d, outline=(30, 30, 40))
    d.rectangle([ox + 22, oy + 12, ox + 40, oy + 21], fill=(150, 214, 240), outline=(30, 30, 40))
    tanuki_head(ox + 21, oy + 2)
    d.rectangle([ox + 50, oy + 24, ox + 56, oy + 30], fill=trim)
    d.rectangle([ox + 4, oy + 24, ox + 8, oy + 29], fill=(255, 230, 140))
    d.ellipse([ox + 2, oy + 4, ox + 10, oy + 12], fill=body_d, outline=(30, 30, 40))
    d.rectangle([ox + 6, oy + 33, ox + 54, oy + 36], fill=body_d)


draw_car(LAYOUT["car_red"]["x"], LAYOUT["car_red"]["y"], (222, 70, 70), (176, 44, 48), (255, 210, 90))
draw_car(LAYOUT["car_blue"]["x"], LAYOUT["car_blue"]["y"], (74, 120, 224), (44, 78, 176), (150, 220, 255))

L = LAYOUT["wheel"]
wx, wy = L["x"], L["y"]
d.ellipse([wx, wy, wx + 15, wy + 15], fill=(40, 40, 48), outline=(20, 20, 26))
d.ellipse([wx + 4, wy + 4, wx + 11, wy + 11], fill=(120, 120, 132))
d.ellipse([wx + 6, wy + 6, wx + 9, wy + 9], fill=(60, 60, 70))

tanuki_head(LAYOUT["head_red"]["x"], LAYOUT["head_red"]["y"])
tanuki_head(LAYOUT["head_blue"]["x"], LAYOUT["head_blue"]["y"])

L = LAYOUT["title"]
tx, ty = L["x"], L["y"]
text = "CRASH IT"
big_font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 64)
tmp = Image.new("L", (10, 10))
bb = ImageDraw.Draw(tmp).textbbox((0, 0), text, font=big_font)
tw, th = bb[2] - bb[0], bb[3] - bb[1]
layer = Image.new("RGBA", (tw + 40, th + 40), (0, 0, 0, 0))
ld = ImageDraw.Draw(layer)
ox2, oy2 = 20 - bb[0], 20 - bb[1]
for dx in range(-3, 4):
    for dy in range(-3, 4):
        if dx * dx + dy * dy <= 9:
            ld.text((ox2 + dx, oy2 + dy), text, font=big_font, fill=(30, 20, 20))
mask = Image.new("L", layer.size, 0)
ImageDraw.Draw(mask).text((ox2, oy2), text, font=big_font, fill=255)
mask_np = np.array(mask)
grad = np.zeros((layer.height, layer.width, 4), dtype=np.uint8)
top = np.array([255, 210, 70])
bot = np.array([220, 70, 40])
for y in range(layer.height):
    t = y / layer.height
    c = (top * (1 - t) + bot * t).astype(np.uint8)
    grad[y, :, 0] = c[0]
    grad[y, :, 1] = c[1]
    grad[y, :, 2] = c[2]
grad[:, :, 3] = mask_np
layer.alpha_composite(Image.fromarray(grad, "RGBA"))
crack = Image.new("RGBA", layer.size, (0, 0, 0, 0))
cd = ImageDraw.Draw(crack)
cx = layer.width // 2
cd.line([(cx, 20), (cx - 6, 40), (cx + 5, 60), (cx - 4, layer.height - 20)], fill=(40, 20, 20), width=2)
crack_masked = np.array(crack)
crack_masked[:, :, 3] = np.minimum(crack_masked[:, :, 3], mask_np)
layer.alpha_composite(Image.fromarray(crack_masked, "RGBA"))
bb2 = layer.getbbox()
layer = layer.crop(bb2)
scale = min(L["w"] / layer.width, L["h"] / layer.height)
nw, nh = int(layer.width * scale), int(layer.height * scale)
layer = layer.resize((nw, nh), Image.LANCZOS)
sheet.alpha_composite(layer, (tx + (L["w"] - nw) // 2, ty + (L["h"] - nh) // 2))

sheet.save("sprites.png")
print("sprites.png built", sheet.size)

config = {
    "sheet": "sprites.png",
    "sprites": LAYOUT,
    "tuning": {
        "engine_force": 620,
        "reverse_force": 420,
        "gravity": 900,
        "max_angular": 240,
        "torque": 520,
        "linear_damp": 0.86,
        "angular_damp": 0.82,
        "bounce": 0.45,
        "wins_to_match": 5,
    },
}
with open("sprites.json", "w") as f:
    json.dump(config, f, indent=2)
print("sprites.json built")

marked = sheet.copy()
md = ImageDraw.Draw(marked)
try:
    font_s = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 10)
except OSError:
    font_s = ImageFont.load_default()
colors = {
    "car_red": (255, 100, 100), "car_blue": (120, 170, 255), "wheel": (200, 200, 200),
    "head_red": (255, 160, 120), "head_blue": (160, 200, 255), "title": (255, 220, 90),
}
for name, s in LAYOUT.items():
    color = colors[name]
    md.rectangle([s["x"], s["y"], s["x"] + s["w"] - 1, s["y"] + s["h"] - 1], outline=color, width=1)
    md.text((s["x"] + 2, s["y"] + 1), name, font=font_s, fill=color)
marked.save("sprites_marked.png")
print("sprites_marked.png built")

icon = Image.new("RGBA", (256, 256), (0, 0, 0, 0))
ic = ImageDraw.Draw(icon)
for y in range(256):
    t = y / 256
    ic.rectangle([0, y, 256, y + 1], fill=(int(60 + 40 * t), int(50 + 20 * t), int(70 + 30 * t)))
red = sheet.crop((0, 0, 60, 40)).resize((150, 100), Image.NEAREST)
blue = sheet.crop((70, 0, 130, 40)).resize((150, 100), Image.NEAREST).transpose(Image.FLIP_LEFT_RIGHT)
icon.alpha_composite(red, (10, 90))
icon.alpha_composite(blue, (96, 130))
t = LAYOUT["title"]
logo = sheet.crop((t["x"], t["y"], t["x"] + t["w"], t["y"] + t["h"]))
lb = logo.getbbox()
logo = logo.crop(lb)
lw = 230
lh = int(logo.height * lw / logo.width)
icon.alpha_composite(logo.resize((lw, lh), Image.NEAREST), (13, 20))
icon.save("icon.png")
print("icon.png built")
