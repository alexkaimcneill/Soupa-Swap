import os
import sys
import json
import math
import random
import pygame

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
VIRTUAL_W, VIRTUAL_H = 512, 300


def load_config():
    with open(os.path.join(BASE_DIR, "sprites.json")) as f:
        return json.load(f)


def slice_sheet(config):
    sheet = pygame.image.load(os.path.join(BASE_DIR, config["sheet"])).convert_alpha()
    sprites = {}
    for name, s in config["sprites"].items():
        sprites[name] = sheet.subsurface(pygame.Rect(s["x"], s["y"], s["w"], s["h"])).copy()
    return sprites


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


class Car:
    def __init__(self, x, y, facing, body_sprite, head_sprite, wheel_sprite, controls, color):
        self.x = x
        self.y = y
        self.vx = 0.0
        self.vy = 0.0
        self.angle = 0.0
        self.av = 0.0
        self.facing = facing
        self.body = body_sprite
        self.head = head_sprite
        self.wheel = wheel_sprite
        self.controls = controls
        self.color = color
        self.w = body_sprite.get_width()
        self.h = body_sprite.get_height()
        self.dead = False

    def reset(self, x, y, facing):
        self.x = x
        self.y = y
        self.vx = 0.0
        self.vy = 0.0
        self.angle = 0.0
        self.av = 0.0
        self.facing = facing
        self.dead = False

    def head_pos(self):
        cxk = math.cos(math.radians(self.angle))
        syk = math.sin(math.radians(self.angle))
        local_x = 0
        local_y = -self.h * 0.42
        hx = self.x + local_x * cxk - local_y * syk * self.facing
        hy = self.y + local_x * syk + local_y * cxk
        return hx, hy

    def corners(self):
        cxk = math.cos(math.radians(self.angle))
        syk = math.sin(math.radians(self.angle))
        hw, hh = self.w * 0.42, self.h * 0.42
        pts = []
        for lx, ly in [(-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh)]:
            px = self.x + lx * cxk - ly * syk
            py = self.y + lx * syk + ly * cxk
            pts.append((px, py))
        return pts


class Game:
    def __init__(self):
        pygame.init()
        pygame.mouse.set_visible(False)
        flags = pygame.FULLSCREEN
        size = (0, 0)
        if os.environ.get("GAME_WINDOWED"):
            flags = 0
            size = (1024, 600)
        self.screen = pygame.display.set_mode(size, flags)
        pygame.display.set_caption("Crash It")
        self.sw, self.sh = self.screen.get_size()
        scale = min(self.sw // VIRTUAL_W, self.sh // VIRTUAL_H)
        self.scale = max(1, scale)
        self.out_w = VIRTUAL_W * self.scale
        self.out_h = VIRTUAL_H * self.scale
        self.out_x = (self.sw - self.out_w) // 2
        self.out_y = (self.sh - self.out_h) // 2
        self.canvas = pygame.Surface((VIRTUAL_W, VIRTUAL_H))
        self.clock = pygame.time.Clock()
        self.config = load_config()
        self.sprites = slice_sheet(self.config)
        self.t = self.config["tuning"]
        self.font = pygame.font.SysFont("dejavusansmono", 26, bold=True)
        self.font_small = pygame.font.SysFont("dejavusans", 14)
        self.font_big = pygame.font.SysFont("dejavusansmono", 34, bold=True)
        pygame.joystick.init()
        self.joysticks = [pygame.joystick.Joystick(i) for i in range(pygame.joystick.get_count())]
        for js in self.joysticks:
            js.init()
        self.build_arena()
        self.p1_controls = {"left": pygame.K_a, "right": pygame.K_d, "gas": pygame.K_w, "rev": pygame.K_s}
        self.p2_controls = {"left": pygame.K_LEFT, "right": pygame.K_RIGHT, "gas": pygame.K_UP, "rev": pygame.K_DOWN}
        self.cars = [
            Car(140, 180, 1, self.sprites["car_red"], self.sprites["head_red"],
                self.sprites["wheel"], self.p1_controls, (222, 70, 70)),
            Car(372, 180, -1, self.sprites["car_blue"], self.sprites["head_blue"],
                self.sprites["wheel"], self.p2_controls, (74, 120, 224)),
        ]
        self.wins = [0, 0]
        self.state = "title"
        self.round_over_t = 0.0
        self.winner = None
        self.anim_t = 0.0
        self.spawn_points = [(140, 150, 1), (372, 150, -1)]

    def build_arena(self):
        self.walls = []
        m = 14
        self.walls.append(pygame.Rect(0, 0, VIRTUAL_W, m))
        self.walls.append(pygame.Rect(0, VIRTUAL_H - m, VIRTUAL_W, m))
        self.walls.append(pygame.Rect(0, 0, m, VIRTUAL_H))
        self.walls.append(pygame.Rect(VIRTUAL_W - m, 0, m, VIRTUAL_H))
        self.floor_y = VIRTUAL_H - m
        self.arc_center = (VIRTUAL_W // 2, -60)
        self.arc_radius = 210
        self.platforms = [
            pygame.Rect(90, 210, 70, 12),
            pygame.Rect(VIRTUAL_W - 160, 210, 70, 12),
        ]

    def reset_round(self):
        for car, (sx, sy, sf) in zip(self.cars, self.spawn_points):
            car.reset(sx, sy, sf)
        self.round_over_t = 0.0
        self.winner = None

    def reset_match(self):
        self.wins = [0, 0]
        self.reset_round()

    def quit(self):
        pygame.quit()
        sys.exit(0)

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.quit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.quit()
                elif event.key in (pygame.K_SPACE, pygame.K_RETURN):
                    self.advance()
            elif event.type == pygame.JOYBUTTONDOWN:
                if event.button in (6, 7, 8, 9):
                    self.quit()
                elif event.button == 0:
                    self.advance()

    def advance(self):
        if self.state == "title":
            self.reset_match()
            self.state = "play"
        elif self.state == "matchover":
            self.state = "title"

    def car_input(self, car, idx):
        keys = pygame.key.get_pressed()
        c = car.controls
        turn = 0.0
        drive = 0.0
        if keys[c["left"]]:
            turn -= 1
        if keys[c["right"]]:
            turn += 1
        if keys[c["gas"]]:
            drive += 1
        if keys[c["rev"]]:
            drive -= 1
        if idx < len(self.joysticks):
            js = self.joysticks[idx]
            if js.get_numaxes() >= 1:
                ax = js.get_axis(0)
                if abs(ax) > 0.3:
                    turn = ax
            if js.get_numaxes() >= 2:
                ay = js.get_axis(1)
                if abs(ay) > 0.3:
                    drive = -ay
            if js.get_numbuttons() > 0 and js.get_button(0):
                drive = 1
        return turn, drive

    def update(self, dt):
        self.anim_t += dt
        if self.state != "play":
            return
        if self.round_over_t > 0:
            self.round_over_t -= dt
            if self.round_over_t <= 0:
                if max(self.wins) >= self.t["wins_to_match"]:
                    self.state = "matchover"
                else:
                    self.reset_round()
            return

        for idx, car in enumerate(self.cars):
            turn, drive = self.car_input(car, idx)
            on_ground = self.car_on_surface(car)
            if on_ground:
                car.av += turn * self.t["torque"] * dt
                fdir = math.radians(car.angle)
                fx = math.cos(fdir) * car.facing
                fy = math.sin(fdir) * car.facing
                if drive > 0:
                    car.vx += fx * self.t["engine_force"] * dt
                    car.vy += fy * self.t["engine_force"] * dt
                elif drive < 0:
                    car.vx -= fx * self.t["reverse_force"] * dt
                    car.vy -= fy * self.t["reverse_force"] * dt
            else:
                car.av += turn * self.t["torque"] * 0.4 * dt

            car.vy += self.t["gravity"] * dt
            car.av = clamp(car.av, -self.t["max_angular"], self.t["max_angular"])
            damp = self.t["linear_damp"] ** (dt * 60)
            adamp = self.t["angular_damp"] ** (dt * 60)
            car.vx *= damp
            car.vy *= damp
            car.av *= adamp
            car.x += car.vx * dt
            car.y += car.vy * dt
            car.angle += car.av * dt

            self.collide_walls(car)
            self.collide_platforms(car)

        self.collide_cars()

        for idx, car in enumerate(self.cars):
            if self.head_hits_anything(car):
                other = 1 - idx
                self.wins[other] += 1
                self.winner = other
                self.round_over_t = 1.8
                break

    def car_on_surface(self, car):
        for c in car.corners():
            if c[1] >= self.floor_y - 2:
                return True
            for p in self.platforms:
                if p.left <= c[0] <= p.right and abs(c[1] - p.top) < 4:
                    return True
        return False

    def collide_walls(self, car):
        b = self.t["bounce"]
        left = 14 + car.w * 0.30
        right = VIRTUAL_W - 14 - car.w * 0.30
        top = 14 + car.h * 0.30
        bottom = VIRTUAL_H - 14 - car.h * 0.30
        if car.x < left:
            car.x = left
            car.vx = abs(car.vx) * b
            car.av += 40
        elif car.x > right:
            car.x = right
            car.vx = -abs(car.vx) * b
            car.av -= 40
        if car.y < top:
            car.y = top
            car.vy = abs(car.vy) * b
        elif car.y > bottom:
            car.y = bottom
            car.vy = -abs(car.vy) * b
            car.av *= 0.7

    def collide_platforms(self, car):
        for p in self.platforms:
            cr = pygame.Rect(int(car.x - car.w * 0.30), int(car.y - car.h * 0.30),
                             int(car.w * 0.6), int(car.h * 0.6))
            if cr.colliderect(p):
                overlap_top = (car.y + car.h * 0.3) - p.top
                if 0 < overlap_top < 16 and car.vy > 0:
                    car.y = p.top - car.h * 0.3
                    car.vy = -car.vy * self.t["bounce"] * 0.5

    def collide_cars(self):
        a, b = self.cars
        dx = b.x - a.x
        dy = b.y - a.y
        dist = math.hypot(dx, dy)
        min_dist = (a.w + b.w) * 0.30
        if dist < min_dist and dist > 0.1:
            nx, ny = dx / dist, dy / dist
            overlap = min_dist - dist
            a.x -= nx * overlap / 2
            a.y -= ny * overlap / 2
            b.x += nx * overlap / 2
            b.y += ny * overlap / 2
            rvx = b.vx - a.vx
            rvy = b.vy - a.vy
            vn = rvx * nx + rvy * ny
            if vn < 0:
                imp = -(1 + self.t["bounce"]) * vn / 2
                a.vx -= imp * nx
                a.vy -= imp * ny
                b.vx += imp * nx
                b.vy += imp * ny
                spin = (rvx * ny - rvy * nx) * 0.6
                a.av += spin
                b.av += spin

    def head_hits_anything(self, car):
        hx, hy = car.head_pos()
        r = 8
        if hx - r < 14 or hx + r > VIRTUAL_W - 14:
            return True
        if hy - r < 14 or hy + r > VIRTUAL_H - 14:
            return True
        for p in self.platforms:
            if p.left - r < hx < p.right + r and p.top - r < hy < p.bottom + r:
                return True
        other = self.cars[1] if car is self.cars[0] else self.cars[0]
        hit = pygame.Rect(int(hx - r), int(hy - r), r * 2, r * 2)
        ocr = pygame.Rect(int(other.x - other.w * 0.30), int(other.y - other.h * 0.30),
                          int(other.w * 0.6), int(other.h * 0.6))
        if hit.colliderect(ocr):
            return True
        return False

    def draw_arena(self):
        self.canvas.fill((58, 44, 64))
        for y in range(0, VIRTUAL_H, 4):
            shade = 44 + int(18 * y / VIRTUAL_H)
            pygame.draw.line(self.canvas, (shade, shade - 8, shade + 6), (0, y), (VIRTUAL_W, y))
        wall_col = (40, 30, 46)
        edge = (90, 70, 100)
        for w in self.walls:
            pygame.draw.rect(self.canvas, wall_col, w)
            pygame.draw.rect(self.canvas, edge, w, 2)
        for p in self.platforms:
            pygame.draw.rect(self.canvas, (70, 52, 78), p, border_radius=3)
            pygame.draw.rect(self.canvas, edge, p, 1, border_radius=3)

    def draw_car(self, car, blink=False):
        img = pygame.transform.rotate(
            pygame.transform.flip(car.body, car.facing < 0, False), -car.angle)
        rect = img.get_rect(center=(int(car.x), int(car.y)))
        if not blink or int(self.anim_t * 12) % 2 == 0:
            self.canvas.blit(img, rect)

    def draw(self):
        self.draw_arena()
        if self.state == "title":
            title = self.sprites["title"]
            self.canvas.blit(title, (VIRTUAL_W // 2 - title.get_width() // 2, 40))
            r = self.sprites["car_red"]
            b = pygame.transform.flip(self.sprites["car_blue"], True, False)
            self.canvas.blit(r, (150, 150))
            self.canvas.blit(b, (302, 150))
            lines = [
                "2 PLAYERS - bonk the other's head!",
                "P1: W/A/D drive+turn   P2: Arrow keys",
                f"First to {self.t['wins_to_match']} wins",
                "Press A / Space to start",
            ]
            for i, ln in enumerate(lines):
                t = self.font_small.render(ln, True, (235, 225, 240) if i < 3 else (255, 240, 160))
                self.canvas.blit(t, (VIRTUAL_W // 2 - t.get_width() // 2, 200 + i * 20))
        else:
            for idx, car in enumerate(self.cars):
                blink = (self.winner is not None and self.winner != idx)
                self.draw_car(car, blink=blink)
            self.draw_score()
            if self.round_over_t > 0 and self.winner is not None:
                col = self.cars[self.winner].color
                label = f"P{self.winner + 1} SCORES!"
                t = self.font.render(label, True, col)
                self.canvas.blit(t, (VIRTUAL_W // 2 - t.get_width() // 2, 120))
            if self.state == "matchover":
                col = self.cars[self.winner].color
                t = self.font_big.render(f"P{self.winner + 1} WINS!", True, col)
                self.canvas.blit(t, (VIRTUAL_W // 2 - t.get_width() // 2, 110))
                h = self.font_small.render("Press A / Space for title", True, (255, 255, 255))
                self.canvas.blit(h, (VIRTUAL_W // 2 - h.get_width() // 2, 160))
        scaled = pygame.transform.scale(self.canvas, (self.out_w, self.out_h))
        self.screen.fill((0, 0, 0))
        self.screen.blit(scaled, (self.out_x, self.out_y))
        pygame.display.flip()

    def draw_score(self):
        r_head = self.sprites["head_red"]
        b_head = self.sprites["head_blue"]
        self.canvas.blit(r_head, (20, 20))
        p1 = self.font.render(str(self.wins[0]), True, (255, 120, 120))
        self.canvas.blit(p1, (44, 18))
        p2 = self.font.render(str(self.wins[1]), True, (140, 180, 255))
        self.canvas.blit(p2, (VIRTUAL_W - 44 - p2.get_width(), 18))
        self.canvas.blit(b_head, (VIRTUAL_W - 20 - b_head.get_width(), 20))

    def run(self):
        while True:
            dt = min(self.clock.tick(60) / 1000.0, 0.033)
            self.handle_events()
            self.update(dt)
            self.draw()


if __name__ == "__main__":
    Game().run()
