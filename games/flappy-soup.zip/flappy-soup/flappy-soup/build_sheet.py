from PIL import Image, ImageDraw, ImageFont
import json

SHEET_W, SHEET_H = 512, 540

LAYOUT = {
    "background": {"x": 0, "y": 0, "w": 512, "h": 300},
    "ground": {"x": 0, "y": 310, "w": 64, "h": 40},
    "pipe_cap": {"x": 80, "y": 310, "w": 60, "h": 24},
    "pipe_body": {"x": 160, "y": 310, "w": 52, "h": 24},
    "bird": {"x": 240, "y": 310, "w": 40, "h": 31, "frames": 3, "vertical": True},
    "gameover": {"x": 300, "y": 310, "w": 200, "h": 44},
    "title": {"x": 0, "y": 415, "w": 300, "h": 115},
}

boxes = []
for name, s in LAYOUT.items():
    frames = s.get("frames", 1)
    total_h = s["h"] * frames if s.get("vertical") else s["h"]
    boxes.append((name, s["x"], s["y"], s["x"] + s["w"], s["y"] + total_h))
for i in range(len(boxes)):
    for j in range(i + 1, len(boxes)):
        n1, a, b, c, e = boxes[i]
        n2, f, g, h, k = boxes[j]
        assert not (a < h and f < c and b < k and g < e), f"OVERLAP {n1}/{n2}"
for name, x1, y1, x2, y2 in boxes:
    assert x2 <= SHEET_W and y2 <= SHEET_H, f"OUT OF BOUNDS {name}"
print("layout verified: no overlaps, all in bounds")

sheet = Image.new("RGBA", (SHEET_W, SHEET_H), (0, 0, 0, 0))
d = ImageDraw.Draw(sheet)

L = LAYOUT["background"]
sky_bands = [
    (26, 16, 60), (44, 22, 82), (70, 28, 100), (105, 36, 110),
    (150, 48, 110), (196, 70, 100), (232, 108, 90), (250, 150, 92),
]
band_h = 130 // len(sky_bands)
y = 0
for c in sky_bands:
    d.rectangle([0, y, 512, y + band_h], fill=c)
    y += band_h
d.rectangle([0, y, 512, 300], fill=(250, 150, 92))
d.ellipse([210, 96, 260, 146], fill=(255, 214, 140))
d.ellipse([220, 106, 250, 136], fill=(255, 236, 190))

def building(x, w, top, color, win_color, win_step=8):
    d.rectangle([x, top, x + w, 236], fill=color)
    for wy in range(top + 6, 232, win_step):
        for wx in range(x + 3, x + w - 3, 7):
            if (wx * 7 + wy * 13) % 5 != 0:
                d.rectangle([wx, wy, wx + 3, wy + 3], fill=win_color)

far = (52, 30, 84)
for x, w, t in [(0, 40, 150), (38, 30, 168), (300, 44, 158), (430, 50, 148), (470, 42, 166)]:
    d.rectangle([x, t, x + w, 236], fill=far)

d.polygon([(150, 40), (186, 40), (192, 236), (144, 236)], fill=(38, 26, 70))
d.polygon([(158, 18), (178, 18), (186, 40), (150, 40)], fill=(38, 26, 70))
d.rectangle([164, 6, 172, 18], fill=(38, 26, 70))
for wy in range(46, 232, 7):
    for wx in range(150, 188, 6):
        if (wx + wy) % 4 != 0:
            d.rectangle([wx, wy, wx + 2, wy + 3], fill=(255, 200, 120))

d.rectangle([230, 70, 268, 236], fill=(46, 32, 88))
d.pieslice([230, 50, 268, 90], 180, 360, fill=(46, 32, 88))
for wy in range(78, 232, 8):
    for wx in range(234, 266, 7):
        if (wx * 3 + wy) % 5 != 0:
            d.rectangle([wx, wy, wx + 3, wy + 3], fill=(150, 230, 255))

building(60, 46, 110, (60, 36, 96), (255, 180, 110))
building(112, 34, 130, (48, 30, 80), (170, 240, 255))
building(200, 26, 120, (58, 34, 92), (255, 210, 130))
building(280, 40, 95, (44, 28, 76), (255, 170, 190))
building(330, 52, 125, (62, 38, 100), (255, 220, 150))
building(388, 38, 105, (50, 32, 84), (160, 235, 255))

d.line([(354, 125), (354, 100)], fill=(30, 20, 55), width=2)
d.ellipse([351, 97, 357, 103], fill=(255, 60, 80))
d.ellipse([165, 2, 171, 8], fill=(255, 60, 80))
d.rectangle([292, 150, 318, 158], fill=(255, 70, 120))
d.rectangle([66, 160, 102, 166], fill=(90, 240, 220))

d.rectangle([0, 236, 512, 244], fill=(255, 150, 120))
d.rectangle([0, 244, 512, 300], fill=(70, 40, 110))
for wy in range(248, 298, 6):
    for wx in range(0, 512, 14):
        if (wx + wy * 3) % 4 == 0:
            d.rectangle([wx, wy, wx + 6, wy + 1], fill=(255, 170, 140))

L = LAYOUT["ground"]
gx, gy = L["x"], L["y"]
d.rectangle([gx, gy, gx + 64, gy + 40], fill=(120, 84, 60))
d.rectangle([gx, gy, gx + 64, gy + 10], fill=(96, 190, 110))
d.rectangle([gx, gy + 10, gx + 64, gy + 13], fill=(70, 140, 82))
for i in range(0, 64, 8):
    d.rectangle([gx + i, gy + 16 + (i // 8 % 2) * 6, gx + i + 4, gy + 18 + (i // 8 % 2) * 6], fill=(140, 100, 72))

L = LAYOUT["pipe_cap"]
cx, cy = L["x"], L["y"]
d.rectangle([cx, cy, cx + 59, cy + 23], fill=(190, 60, 50), outline=(60, 20, 20))
d.rectangle([cx + 4, cy + 4, cx + 55, cy + 8], fill=(230, 110, 90))
d.rectangle([cx, cy + 20, cx + 59, cy + 23], fill=(140, 40, 36))
d.rectangle([cx + 8, cy + 10, cx + 14, cy + 16], fill=(255, 210, 120))
d.rectangle([cx + 45, cy + 10, cx + 51, cy + 16], fill=(255, 210, 120))

L = LAYOUT["pipe_body"]
bx, by = L["x"], L["y"]
d.rectangle([bx, by, bx + 51, by + 23], fill=(200, 72, 58))
d.rectangle([bx, by, bx + 6, by + 23], fill=(232, 116, 92))
d.rectangle([bx + 45, by, bx + 51, by + 23], fill=(150, 46, 40))
d.rectangle([bx + 20, by + 8, bx + 31, by + 12], fill=(240, 200, 120))

def soup_bird(ox, oy, wing):
    w, h = 40, 31
    d.ellipse([ox + 3, oy + 10, ox + 37, oy + 29], fill=(235, 240, 245), outline=(40, 40, 60))
    d.rectangle([ox + 4, oy + 16, ox + 36, oy + 19], fill=(210, 60, 70))
    d.ellipse([ox + 6, oy + 3, ox + 34, oy + 17], fill=(250, 190, 90), outline=(40, 40, 60))
    d.ellipse([ox + 11, oy + 5, ox + 18, oy + 10], fill=(255, 230, 170))
    d.line([(ox + 14, oy + 3), (ox + 12, oy)], fill=(80, 80, 90), width=1)
    d.line([(ox + 20, oy + 3), (ox + 21, oy)], fill=(80, 80, 90), width=1)
    d.line([(ox + 26, oy + 3), (ox + 28, oy)], fill=(80, 80, 90), width=1)
    d.ellipse([ox + 28, oy + 11, ox + 35, oy + 18], fill=(255, 255, 255), outline=(40, 40, 60))
    d.ellipse([ox + 31, oy + 13, ox + 34, oy + 16], fill=(30, 30, 50))
    d.polygon([(ox + 36, oy + 15), (ox + 40, oy + 17), (ox + 36, oy + 19)], fill=(255, 140, 60))
    if wing == 0:
        d.polygon([(ox + 8, oy + 17), (ox + 1, oy + 8), (ox + 15, oy + 14)], fill=(255, 255, 255))
        d.polygon([(ox + 8, oy + 17), (ox + 1, oy + 8), (ox + 15, oy + 14)], outline=(40, 40, 60))
    elif wing == 1:
        d.polygon([(ox + 6, oy + 18), (ox + 0, oy + 18), (ox + 14, oy + 16)], fill=(255, 255, 255))
        d.polygon([(ox + 6, oy + 18), (ox + 0, oy + 18), (ox + 14, oy + 16)], outline=(40, 40, 60))
    else:
        d.polygon([(ox + 8, oy + 20), (ox + 1, oy + 28), (ox + 15, oy + 21)], fill=(255, 255, 255))
        d.polygon([(ox + 8, oy + 20), (ox + 1, oy + 28), (ox + 15, oy + 21)], outline=(40, 40, 60))

L = LAYOUT["bird"]
for f in range(3):
    soup_bird(L["x"], L["y"] + f * L["h"], f)

try:
    font_title = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 40)
    font_go = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 26)
except OSError:
    font_title = font_go = ImageFont.load_default()

def outlined_text(x, y, text, font, fill, outline, ow=2):
    for dx in range(-ow, ow + 1):
        for dy in range(-ow, ow + 1):
            if dx or dy:
                d.text((x + dx, y + dy), text, font=font, fill=outline)
    d.text((x, y), text, font=font, fill=fill)

L = LAYOUT["gameover"]
outlined_text(L["x"] + 8, L["y"] + 6, "GAME OVER", font_go, (255, 240, 220), (120, 30, 40))

L = LAYOUT["title"]
tx, ty = L["x"], L["y"]
outlined_text(tx + 8, ty + 4, "FLAPPY", font_title, (255, 210, 90), (90, 30, 30))
outlined_text(tx + 120, ty + 52, "SOUP", font_title, (255, 120, 100), (90, 30, 30))
d.ellipse([tx + 240, ty + 16, tx + 284, ty + 50], fill=(235, 240, 245), outline=(40, 40, 60))
d.rectangle([tx + 240, ty + 30, tx + 284, ty + 34], fill=(210, 60, 70))
d.ellipse([tx + 246, ty + 8, tx + 278, ty + 30], fill=(250, 190, 90), outline=(40, 40, 60))
d.line([(tx + 252, ty + 10), (tx + 250, ty + 4)], fill=(200, 200, 210), width=2)
d.line([(tx + 262, ty + 8), (tx + 262, ty + 2)], fill=(200, 200, 210), width=2)
d.line([(tx + 272, ty + 10), (tx + 274, ty + 4)], fill=(200, 200, 210), width=2)

sheet.save("sprites.png")
print("sprites.png rebuilt", sheet.size)

config = {
    "sheet": "sprites.png",
    "sprites": LAYOUT,
    "tuning": {
        "gravity": 900,
        "flap_velocity": -255,
        "pipe_speed": 115,
        "pipe_gap": 95,
        "pipe_interval": 1.7,
        "ground_speed": 115,
        "animation_fps": 8,
    },
}
with open("sprites.json", "w") as f:
    json.dump(config, f, indent=2)
print("sprites.json rebuilt")

marked = sheet.copy()
md = ImageDraw.Draw(marked)
try:
    font_s = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 10)
except OSError:
    font_s = ImageFont.load_default()
colors = {
    "background": (0, 255, 100), "ground": (255, 200, 0), "bird": (255, 100, 200),
    "pipe_cap": (255, 60, 60), "pipe_body": (255, 150, 100),
    "title": (100, 150, 255), "gameover": (200, 100, 255),
}
for name, s in LAYOUT.items():
    color = colors[name]
    frames = s.get("frames", 1)
    if frames > 1 and s.get("vertical"):
        for i in range(frames):
            yy = s["y"] + i * s["h"]
            md.rectangle([s["x"], yy, s["x"] + s["w"] - 1, yy + s["h"] - 1], outline=color, width=1)
            md.text((s["x"] + 2, yy + 1), f"{name}{i}", font=font_s, fill=color)
    else:
        md.rectangle([s["x"], s["y"], s["x"] + s["w"] - 1, s["y"] + s["h"] - 1], outline=color, width=1)
        md.text((s["x"] + 2, s["y"] + 1), f"{name} {s['x']},{s['y']} {s['w']}x{s['h']}", font=font_s, fill=color)
marked.save("sprites_marked.png")
print("sprites_marked.png rebuilt")

icon = sheet.crop((0, 0, 300, 300)).resize((256, 256), Image.NEAREST)
b = LAYOUT["bird"]
bird_big = sheet.crop((b["x"], b["y"], b["x"] + 40, b["y"] + 31)).resize((160, 124), Image.NEAREST)
icon.alpha_composite(bird_big, (48, 70))
icon.save("icon.png")
print("icon.png rebuilt")
