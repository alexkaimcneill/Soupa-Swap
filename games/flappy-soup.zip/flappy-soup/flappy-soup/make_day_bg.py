from PIL import Image, ImageDraw
import json

W, H = 512, 300
bg = Image.new("RGBA", (W, H), (0, 0, 0, 0))
d = ImageDraw.Draw(bg)

sky_bands = [
    (108, 190, 240), (118, 197, 243), (128, 204, 246), (140, 211, 248),
    (152, 218, 250), (166, 224, 252), (180, 231, 253), (196, 238, 255),
]
band_h = H // len(sky_bands)
y = 0
for c in sky_bands:
    d.rectangle([0, y, W, y + band_h + 1], fill=c)
    y += band_h

d.ellipse([408, 18, 462, 72], fill=(255, 244, 190))
d.ellipse([416, 26, 454, 64], fill=(255, 252, 224))

def cloud(x, y, s, shade=False):
    c = (235, 243, 250) if shade else (255, 255, 255)
    d.ellipse([x, y + 4*s, x + 16*s, y + 12*s], fill=c)
    d.ellipse([x + 8*s, y, x + 26*s, y + 12*s], fill=c)
    d.ellipse([x + 20*s, y + 3*s, x + 36*s, y + 12*s], fill=c)
    d.rectangle([x + 4*s, y + 8*s, x + 32*s, y + 12*s], fill=c)

cloud(30, 30, 2)
cloud(200, 60, 1.4, shade=True)
cloud(330, 25, 1.8)
cloud(90, 110, 1.1, shade=True)
cloud(420, 100, 1.3)
cloud(-20, 165, 1.5, shade=True)
cloud(250, 140, 1.0)

far = (172, 205, 228)
for x, w, t in [(0, 44, 158), (40, 32, 174), (170, 36, 166), (296, 46, 162), (420, 40, 152), (466, 46, 170)]:
    d.rectangle([x, t, x + w, H], fill=far)

def building(x, w, top, color, win_color, win_step=8):
    d.rectangle([x, top, x + w, H], fill=color)
    d.rectangle([x, top, x + 3, H], fill=tuple(min(255, c + 22) for c in color))
    for wy in range(top + 6, H - 4, win_step):
        for wx in range(x + 4, x + w - 4, 7):
            if (wx * 7 + wy * 13) % 5 != 0:
                d.rectangle([wx, wy, wx + 3, wy + 3], fill=win_color)

mid = (124, 164, 196)
mid_win = (208, 232, 248)
for x, w, t in [(74, 40, 130), (240, 34, 138), (368, 44, 126)]:
    building(x, w, t, mid, mid_win, 9)

d.polygon([(150, 60), (186, 60), (192, H), (144, H)], fill=(84, 118, 156))
d.polygon([(158, 36), (178, 36), (186, 60), (150, 60)], fill=(84, 118, 156))
d.rectangle([164, 22, 172, 36], fill=(84, 118, 156))
for wy in range(66, H - 4, 7):
    for wx in range(150, 188, 6):
        if (wx + wy) % 4 != 0:
            d.rectangle([wx, wy, wx + 2, wy + 3], fill=(226, 240, 250))

d.rectangle([230, 92, 268, H], fill=(96, 132, 168))
d.pieslice([230, 72, 268, 112], 180, 360, fill=(96, 132, 168))
for wy in range(100, H - 4, 8):
    for wx in range(234, 266, 7):
        if (wx * 3 + wy) % 5 != 0:
            d.rectangle([wx, wy, wx + 3, wy + 3], fill=(214, 236, 250))

building(56, 30, 150, (104, 144, 180), (218, 238, 250))
building(112, 32, 118, (90, 126, 164), (224, 242, 252))
building(200, 26, 142, (110, 150, 184), (220, 238, 250))
building(280, 42, 108, (86, 122, 160), (216, 236, 250))
building(330, 50, 136, (104, 142, 178), (226, 242, 252))
building(390, 36, 120, (94, 130, 166), (212, 234, 248))
building(436, 40, 146, (112, 152, 186), (222, 240, 252))

d.line([(354, 136), (354, 112)], fill=(70, 100, 134), width=2)
d.ellipse([351, 109, 357, 115], fill=(255, 80, 90))
d.ellipse([165, 18, 171, 24], fill=(255, 80, 90))

bg.save("bg_day.png")
print("day background saved")

sheet = Image.open("sprites.png").convert("RGBA")
cleared = Image.new("RGBA", (W, H), (0, 0, 0, 0))
sheet.paste(cleared, (0, 0))
sheet.alpha_composite(bg, (0, 0))
sheet.save("sprites.png")
print("spritesheet background replaced")

cfg = json.load(open("sprites.json"))
b = cfg["sprites"]["bird"]
icon = sheet.crop((0, 0, 300, 300)).resize((256, 256), Image.NEAREST)
bird_big = sheet.crop((b["x"], b["y"], b["x"] + b["w"], b["y"] + b["h"])).resize((160, 124), Image.NEAREST)
icon.alpha_composite(bird_big, (48, 70))
icon.save("icon.png")
print("icon updated")
