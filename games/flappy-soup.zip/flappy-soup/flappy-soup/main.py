import os
import sys
import json
import random
import pygame
from name_entry import NameEntry

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
VIRTUAL_W, VIRTUAL_H = 512, 300


def load_config():
    with open(os.path.join(BASE_DIR, "sprites.json")) as f:
        return json.load(f)


def slice_sheet(config):
    sheet = pygame.image.load(os.path.join(BASE_DIR, config["sheet"])).convert_alpha()
    sprites = {}
    for name, s in config["sprites"].items():
        frames = s.get("frames", 1)
        if frames > 1:
            if s.get("vertical"):
                sprites[name] = [
                    sheet.subsurface(pygame.Rect(s["x"], s["y"] + i * s["h"], s["w"], s["h"])).copy()
                    for i in range(frames)
                ]
            else:
                stride = s.get("stride", s["w"])
                sprites[name] = [
                    sheet.subsurface(pygame.Rect(s["x"] + i * stride, s["y"], s["w"], s["h"])).copy()
                    for i in range(frames)
                ]
        else:
            sprites[name] = sheet.subsurface(pygame.Rect(s["x"], s["y"], s["w"], s["h"])).copy()
    return sprites


class Pipe:
    def __init__(self, x, gap_y, gap, cap, body):
        self.x = x
        self.gap_y = gap_y
        self.gap = gap
        self.cap = cap
        self.body = body
        self.w = cap.get_width()
        self.scored = False

    def rects(self, ground_y):
        top_h = self.gap_y - self.gap // 2
        bot_y = self.gap_y + self.gap // 2
        return [
            pygame.Rect(self.x + 4, 0, self.w - 8, top_h),
            pygame.Rect(self.x + 4, bot_y, self.w - 8, ground_y - bot_y),
        ]

    def draw(self, surf, ground_y):
        top_h = self.gap_y - self.gap // 2
        bot_y = self.gap_y + self.gap // 2
        body_h = self.body.get_height()
        bw = self.body.get_width()
        bx = self.x + (self.w - bw) // 2
        y = top_h - self.cap.get_height() - body_h
        while y > -body_h:
            surf.blit(self.body, (bx, y))
            y -= body_h
        surf.blit(pygame.transform.flip(self.cap, False, True), (self.x, top_h - self.cap.get_height()))
        surf.blit(self.cap, (self.x, bot_y))
        y = bot_y + self.cap.get_height()
        while y < ground_y:
            surf.blit(self.body, (bx, y))
            y += body_h


class Game:
    def __init__(self):
        pygame.init()
        pygame.mouse.set_visible(False)
        flags = pygame.FULLSCREEN
        size = (0, 0)
        if os.environ.get("GAME_WINDOWED"):
            flags = 0
            size = (1024, 600)
        self.screen = pygame.display.set_mode(size, flags)
        pygame.display.set_caption("Flappy Soup")
        self.sw, self.sh = self.screen.get_size()
        scale = min(self.sw // VIRTUAL_W, self.sh // VIRTUAL_H)
        self.scale = max(1, scale)
        self.out_w = VIRTUAL_W * self.scale
        self.out_h = VIRTUAL_H * self.scale
        self.out_x = (self.sw - self.out_w) // 2
        self.out_y = (self.sh - self.out_h) // 2
        self.canvas = pygame.Surface((VIRTUAL_W, VIRTUAL_H))
        self.clock = pygame.time.Clock()
        self.config = load_config()
        self.sprites = slice_sheet(self.config)
        self.tuning = self.config["tuning"]
        self.font = pygame.font.SysFont("dejavusansmono", 28, bold=True)
        self.font_small = pygame.font.SysFont("dejavusans", 14)
        self.ground_h = self.sprites["ground"].get_height()
        self.ground_y = VIRTUAL_H - self.ground_h
        self.scores = self.load_scores()
        self.best = self.scores[0]["score"] if self.scores else 0
        self.name_entry = None
        self.last_name = "SOUP"
        pygame.joystick.init()
        self.joysticks = [pygame.joystick.Joystick(i) for i in range(pygame.joystick.get_count())]
        for js in self.joysticks:
            js.init()
        self.reset()
        self.state = "title"

    def load_scores(self):
        try:
            with open(os.path.join(BASE_DIR, "scores.json")) as f:
                data = json.load(f)
            entries = []
            for e in data.get("scores", []):
                if isinstance(e, dict):
                    entries.append({"name": str(e.get("name", "SOUP"))[:8], "score": int(e.get("score", 0))})
                else:
                    entries.append({"name": "SOUP", "score": int(e)})
            entries.sort(key=lambda x: x["score"], reverse=True)
            return entries[:5]
        except (OSError, json.JSONDecodeError, ValueError, TypeError):
            return []

    def qualifies(self, value):
        if value <= 0:
            return False
        if len(self.scores) < 5:
            return True
        return value > self.scores[-1]["score"]

    def commit_score(self, name, value):
        self.scores.append({"name": name, "score": int(value)})
        self.scores.sort(key=lambda x: x["score"], reverse=True)
        self.scores = self.scores[:5]
        self.best = self.scores[0]["score"] if self.scores else 0
        try:
            with open(os.path.join(BASE_DIR, "scores.json"), "w") as f:
                json.dump({"scores": self.scores}, f)
        except OSError:
            pass

    def reset(self):
        self.bird_x = 100.0
        self.bird_y = VIRTUAL_H / 2
        self.bird_vy = 0.0
        self.pipes = []
        self.spawn_timer = 0.0
        self.scroll = 0.0
        self.score = 0
        self.anim_t = 0.0
        self.flash = 0.0

    def flap(self):
        if self.state == "title":
            self.state = "play"
            self.bird_vy = self.tuning["flap_velocity"]
        elif self.state == "play":
            self.bird_vy = self.tuning["flap_velocity"]
        elif self.state == "dead" and self.flash <= 0 and self.name_entry is None:
            self.reset()
            self.state = "title"

    def quit(self):
        pygame.quit()
        sys.exit(0)

    def start_name_entry(self):
        def done(name):
            self.last_name = name
            self.commit_score(name, self.score)
            self.name_entry = None
        self.name_entry = NameEntry(VIRTUAL_W, VIRTUAL_H, self.font, self.font_small,
                                    done, initial=self.last_name)
        self.name_entry.set_scale(self.out_x, self.out_y, self.scale)

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.quit()
                continue
            if self.name_entry is not None:
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    self.quit()
                else:
                    self.name_entry.handle_event(event)
                continue
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_SPACE, pygame.K_UP, pygame.K_RETURN):
                    self.flap()
                elif event.key == pygame.K_ESCAPE:
                    self.quit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                self.flap()
            elif event.type == pygame.JOYBUTTONDOWN:
                if event.button in (6, 7, 8, 9):
                    self.quit()
                else:
                    self.flap()

    def update(self, dt):
        self.anim_t += dt
        if self.state == "play":
            self.bird_vy += self.tuning["gravity"] * dt
            self.bird_y += self.bird_vy * dt
            self.scroll += self.tuning["ground_speed"] * dt
            self.spawn_timer += dt
            if self.spawn_timer >= self.tuning["pipe_interval"]:
                self.spawn_timer = 0.0
                gap = self.tuning["pipe_gap"]
                gap_y = random.randint(gap // 2 + 30, self.ground_y - gap // 2 - 30)
                self.pipes.append(Pipe(VIRTUAL_W + 10, gap_y, gap,
                                       self.sprites["pipe_cap"], self.sprites["pipe_body"]))
            for pipe in self.pipes:
                pipe.x -= self.tuning["pipe_speed"] * dt
                if not pipe.scored and pipe.x + pipe.w < self.bird_x:
                    pipe.scored = True
                    self.score += 1
            self.pipes = [p for p in self.pipes if p.x > -80]
            bird = self.sprites["bird"][0]
            bird_rect = pygame.Rect(int(self.bird_x) + 4, int(self.bird_y) + 4,
                                    bird.get_width() - 8, bird.get_height() - 8)
            if self.bird_y < -20 or bird_rect.bottom >= self.ground_y:
                self.die()
            else:
                for pipe in self.pipes:
                    for r in pipe.rects(self.ground_y):
                        if bird_rect.colliderect(r):
                            self.die()
                            break
        elif self.state == "title":
            self.scroll += self.tuning["ground_speed"] * dt
            self.bird_y = VIRTUAL_H / 2 + 8 * pygame.math.Vector2(1, 0).rotate(self.anim_t * 180).y
        elif self.state == "dead":
            self.flash = max(0.0, self.flash - dt)
            if self.bird_y + self.sprites["bird"][0].get_height() < self.ground_y:
                self.bird_vy += self.tuning["gravity"] * dt
                self.bird_y += self.bird_vy * dt

    def die(self):
        self.state = "dead"
        self.flash = 0.5
        if self.qualifies(self.score):
            self.start_name_entry()

    def draw_bird(self):
        frames = self.sprites["bird"]
        if self.state == "dead":
            frame = frames[1]
        else:
            frame = frames[int(self.anim_t * self.tuning["animation_fps"]) % len(frames)]
        angle = max(-25, min(70, -self.bird_vy * 0.12)) if self.state != "title" else 0
        rotated = pygame.transform.rotate(frame, angle)
        rect = rotated.get_rect(center=(self.bird_x + frame.get_width() / 2,
                                        self.bird_y + frame.get_height() / 2))
        self.canvas.blit(rotated, rect)

    def draw_ground(self):
        tile = self.sprites["ground"]
        tw = tile.get_width()
        offset = int(self.scroll) % tw
        x = -offset
        while x < VIRTUAL_W:
            self.canvas.blit(tile, (x, self.ground_y))
            x += tw

    def draw_background(self):
        bg = self.sprites["background"]
        bw = bg.get_width()
        offset = int(self.scroll * 0.4) % bw
        x = -offset
        while x < VIRTUAL_W:
            self.canvas.blit(bg, (x, 0))
            x += bw

    def draw_score(self):
        text = self.font.render(str(self.score), True, (255, 255, 255))
        shadow = self.font.render(str(self.score), True, (40, 20, 40))
        cx = VIRTUAL_W // 2 - text.get_width() // 2
        self.canvas.blit(shadow, (cx + 2, 18))
        self.canvas.blit(text, (cx, 16))

    def draw_leaderboard(self, top_y):
        header = self.font_small.render("- BEST -", True, (255, 220, 120))
        self.canvas.blit(header, (VIRTUAL_W // 2 - header.get_width() // 2, top_y))
        if not self.scores:
            none_t = self.font_small.render("no scores yet", True, (200, 200, 210))
            self.canvas.blit(none_t, (VIRTUAL_W // 2 - none_t.get_width() // 2, top_y + 18))
            return
        for i, e in enumerate(self.scores[:5]):
            is_new = (e["score"] == self.score and e["name"] == self.last_name
                      and self.state == "dead")
            color = (255, 255, 160) if is_new else (235, 240, 250)
            name = e["name"][:8].ljust(8)
            row = self.font_small.render(f"{i + 1}. {name} {e['score']}", True, color)
            self.canvas.blit(row, (VIRTUAL_W // 2 - row.get_width() // 2, top_y + 18 + i * 16))

    def draw(self):
        self.draw_background()
        for pipe in self.pipes:
            pipe.draw(self.canvas, self.ground_y)
        self.draw_ground()
        self.draw_bird()
        if self.state == "title":
            title = self.sprites["title"]
            self.canvas.blit(title, (VIRTUAL_W // 2 - title.get_width() // 2, 30))
            hint = self.font_small.render("Press A / Space to start", True, (255, 255, 255))
            self.canvas.blit(hint, (VIRTUAL_W // 2 - hint.get_width() // 2, 150))
            self.draw_leaderboard(170)
        elif self.state == "play":
            self.draw_score()
        elif self.state == "dead":
            go = self.sprites["gameover"]
            self.canvas.blit(go, (VIRTUAL_W // 2 - go.get_width() // 2, 40))
            score_t = self.font.render(f"{self.score}", True, (255, 255, 255))
            self.canvas.blit(score_t, (VIRTUAL_W // 2 - score_t.get_width() // 2, 92))
            self.draw_leaderboard(126)
            if self.name_entry is not None:
                pass
            elif self.flash <= 0:
                hint = self.font_small.render("Press A / Space to retry", True, (255, 255, 255))
                self.canvas.blit(hint, (VIRTUAL_W // 2 - hint.get_width() // 2, 232))
            else:
                overlay = pygame.Surface((VIRTUAL_W, VIRTUAL_H), pygame.SRCALPHA)
                overlay.fill((255, 255, 255, int(140 * self.flash / 0.5)))
                self.canvas.blit(overlay, (0, 0))
        if self.name_entry is not None:
            self.name_entry.draw(self.canvas, accent=(60, 200, 210))
        scaled = pygame.transform.scale(self.canvas, (self.out_w, self.out_h))
        self.screen.fill((0, 0, 0))
        self.screen.blit(scaled, (self.out_x, self.out_y))
        pygame.display.flip()

    def run(self):
        while True:
            dt = min(self.clock.tick(60) / 1000.0, 0.05)
            self.handle_events()
            self.update(dt)
            self.draw()


if __name__ == "__main__":
    Game().run()
