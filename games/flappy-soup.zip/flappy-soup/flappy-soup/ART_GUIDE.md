# Editing the Art in Flappy Soup

All game art lives in ONE file: `sprites.png` (512x540). All positions and sizes live in `sprites.json`. Change the art, keep the layout, and the game just works. No code editing needed.

Open `sprites_marked.png` next to it to see the exact box around every sprite.

## The spritesheet layout

| Sprite | Position (x, y) | Size (w x h) | Notes |
|---|---|---|---|
| background | 0, 0 | 512 x 300 | The whole level backdrop (Shenzhen skyline). Fills the screen. |
| ground | 0, 310 | 64 x 40 | Tiles horizontally and scrolls. Make it seamless left-to-right. |
| pipe_cap | 80, 310 | 60 x 24 | The lip at the end of each pipe. Auto-flipped for top pipes. |
| pipe_body | 160, 310 | 52 x 24 | Tiles vertically to any pipe length. Make it seamless top-to-bottom. |
| bird frame 0 | 240, 310 | 40 x 31 | Wing up |
| bird frame 1 | 240, 341 | 40 x 31 | Wing mid |
| bird frame 2 | 240, 372 | 40 x 31 | Wing down |
| gameover | 300, 310 | 200 x 44 | Shown when you die. |
| title | 0, 415 | 300 x 115 | The FLAPPY SOUP logo on the title screen. |

The three bird frames are stacked directly on top of each other in one 40x93 column, so you can draw all three poses in one strip.

## How to reskin

1. Open `sprites.png` in any pixel editor (Aseprite, Piskel, GIMP, even MS Paint)
2. Use `sprites_marked.png` as your map of where each sprite's box is
3. Draw over any sprite, staying inside its box
4. Save, relaunch the game. Done.

The game renders at 512x300 internally and scales up 2x with hard pixels to 1024x600, so draw at native resolution and it will look crisp.

## Changing sprite sizes or positions

1. Redraw the sprite anywhere on the sheet (the sheet can be any size, add rows below if you need space)
2. Update its entry in `sprites.json` with the new x, y, w, h

Everything is data driven. Hitboxes automatically follow the sprite sizes (with a few pixels of forgiveness built in). For the bird, all 3 frames share one x/w/h and stack vertically starting at its y.

## Gameplay tuning (also no code)

The `tuning` block in `sprites.json`:

- `gravity` - how fast you fall (higher = heavier)
- `flap_velocity` - jump strength (more negative = higher jump)
- `pipe_speed` - how fast pipes come at you
- `pipe_gap` - vertical space between pipes (bigger = easier)
- `pipe_interval` - seconds between pipes
- `ground_speed` - ground scroll speed (match pipe_speed to look right)
- `animation_fps` - wing flap speed

## Testing on a desktop

GAME_WINDOWED=1 python3 main.py

runs it in a 1024x600 window instead of fullscreen. ESC quits.

## Regenerating the default art

`build_sheet.py` is the script that generated the original sheet. If you ever wreck sprites.png, run `python3 build_sheet.py` to restore the defaults (it rebuilds sprites.png, sprites.json, sprites_marked.png, and icon.png).

## Leaderboard (added)

Top 5 scores are saved to `scores.json` in this folder and persist across sessions. They show on the title screen and the game-over screen (your new score is highlighted). Delete `scores.json` to reset the board.
