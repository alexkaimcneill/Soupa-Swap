# Editing Soup Shootout

Art in sprites.png (512x360), positions in sprites.json, no code editing. sprites_marked.png is the box map.

| Sprite | Pos | Size | Notes |
|---|---|---|---|
| tank_red | 0,0 | 40x34 | P1 tank, tanuki driver. Points right; rotates in game. |
| tank_blue | 50,0 | 40x34 | P2 tank. |
| bullet_red | 100,0 | 10x10 | P1 shot. |
| bullet_blue | 120,0 | 10x10 | P2 shot. |
| barrier | 140,0 | 32x32 | Cover blocks; bullets die on them, tanks can't pass. |
| explosion | 180,0 | 26x26 x3 | 3-frame burst (vertical). |
| head_red/blue | 220/250,0 | 20x20 | Scoreboard heads. |
| title | 0,100 | 500x90 | SOUP SHOOTOUT logo. |

Barrier positions are set in build_arena() in main.py if you want to change the map.

## Rules
Top-down tank duel. Rotate + drive, shoot the other tank. Bullets bounce off walls once or twice (by lifetime) and are stopped by barriers. First to wins_to_match wins.

## Controls
P1: WASD to move/turn, Left-Shift to fire.
P2: Arrow keys, Right-Shift to fire.
Space start/continue, Esc quit.

## Tuning (sprites.json)
move_speed, turn_speed, bullet_speed, fire_cooldown, bullet_life (bounce duration), max_bullets, wins_to_match, respawn_delay.

## Rebuild art
python3 build_sheet.py
