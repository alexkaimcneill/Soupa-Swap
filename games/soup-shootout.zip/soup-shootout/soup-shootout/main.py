import os
import sys
import json
import math
import pygame

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
VIRTUAL_W, VIRTUAL_H = 512, 300


def load_config():
    with open(os.path.join(BASE_DIR, "sprites.json")) as f:
        return json.load(f)


def slice_sheet(config):
    sheet = pygame.image.load(os.path.join(BASE_DIR, config["sheet"])).convert_alpha()
    sprites = {}
    for name, s in config["sprites"].items():
        frames = s.get("frames", 1)
        if frames > 1 and s.get("vertical"):
            sprites[name] = [
                sheet.subsurface(pygame.Rect(s["x"], s["y"] + i * s["h"], s["w"], s["h"])).copy()
                for i in range(frames)
            ]
        else:
            sprites[name] = sheet.subsurface(pygame.Rect(s["x"], s["y"], s["w"], s["h"])).copy()
    return sprites


class Tank:
    def __init__(self, x, y, angle, body, bullet, head, controls, color):
        self.body = body
        self.bullet = bullet
        self.head = head
        self.controls = controls
        self.color = color
        self.w = body.get_width()
        self.h = body.get_height()
        self.spawn = (x, y, angle)
        self.reset()

    def reset(self):
        self.x, self.y, self.angle = float(self.spawn[0]), float(self.spawn[1]), float(self.spawn[2])
        self.fire_t = 0.0
        self.alive = True

    def rect(self):
        return pygame.Rect(int(self.x - self.w * 0.35), int(self.y - self.h * 0.35),
                           int(self.w * 0.7), int(self.h * 0.7))


class Game:
    def __init__(self):
        pygame.init()
        pygame.mouse.set_visible(False)
        flags = pygame.FULLSCREEN
        size = (0, 0)
        if os.environ.get("GAME_WINDOWED"):
            flags = 0
            size = (1024, 600)
        self.screen = pygame.display.set_mode(size, flags)
        pygame.display.set_caption("Soup Shootout")
        self.sw, self.sh = self.screen.get_size()
        self.scale = max(1, min(self.sw // VIRTUAL_W, self.sh // VIRTUAL_H))
        self.out_w, self.out_h = VIRTUAL_W * self.scale, VIRTUAL_H * self.scale
        self.out_x = (self.sw - self.out_w) // 2
        self.out_y = (self.sh - self.out_h) // 2
        self.canvas = pygame.Surface((VIRTUAL_W, VIRTUAL_H))
        self.clock = pygame.time.Clock()
        self.config = load_config()
        self.sprites = slice_sheet(self.config)
        self.t = self.config["tuning"]
        self.font = pygame.font.SysFont("dejavusansmono", 26, bold=True)
        self.font_small = pygame.font.SysFont("dejavusans", 14)
        self.font_big = pygame.font.SysFont("dejavusansmono", 34, bold=True)
        pygame.joystick.init()
        self.joysticks = [pygame.joystick.Joystick(i) for i in range(pygame.joystick.get_count())]
        for js in self.joysticks:
            js.init()
        self.build_arena()
        p1 = {"left": pygame.K_a, "right": pygame.K_d, "up": pygame.K_w, "down": pygame.K_s, "fire": pygame.K_LSHIFT}
        p2 = {"left": pygame.K_LEFT, "right": pygame.K_RIGHT, "up": pygame.K_UP, "down": pygame.K_DOWN, "fire": pygame.K_RSHIFT}
        self.tanks = [
            Tank(60, 150, 0, self.sprites["tank_red"], self.sprites["bullet_red"],
                 self.sprites["head_red"], p1, (222, 70, 70)),
            Tank(VIRTUAL_W - 60, 150, 180, self.sprites["tank_blue"], self.sprites["bullet_blue"],
                 self.sprites["head_blue"], p2, (74, 120, 224)),
        ]
        self.bullets = []
        self.explosions = []
        self.wins = [0, 0]
        self.state = "title"
        self.round_over_t = 0.0
        self.winner = None
        self.anim_t = 0.0

    def build_arena(self):
        m = 14
        self.bounds = pygame.Rect(m, m, VIRTUAL_W - 2 * m, VIRTUAL_H - 2 * m)
        self.barriers = [
            pygame.Rect(VIRTUAL_W // 2 - 16, 40, 32, 32),
            pygame.Rect(VIRTUAL_W // 2 - 16, VIRTUAL_H - 72, 32, 32),
            pygame.Rect(VIRTUAL_W // 2 - 16, VIRTUAL_H // 2 - 16, 32, 32),
            pygame.Rect(140, 90, 32, 32),
            pygame.Rect(VIRTUAL_W - 172, 90, 32, 32),
            pygame.Rect(140, VIRTUAL_H - 122, 32, 32),
            pygame.Rect(VIRTUAL_W - 172, VIRTUAL_H - 122, 32, 32),
        ]

    def reset_round(self):
        for tk in self.tanks:
            tk.reset()
        self.bullets = []
        self.explosions = []
        self.round_over_t = 0.0
        self.winner = None

    def quit(self):
        pygame.quit()
        sys.exit(0)

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.quit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.quit()
                elif event.key in (pygame.K_SPACE, pygame.K_RETURN):
                    self.advance()
                elif event.key == self.tanks[0].controls["fire"]:
                    self.fire(0)
                elif event.key == self.tanks[1].controls["fire"]:
                    self.fire(1)
            elif event.type == pygame.JOYBUTTONDOWN:
                if event.button in (6, 7, 8, 9):
                    self.quit()
                elif event.button == 0:
                    idx = self.joysticks.index(event.joy) if hasattr(event, "joy") else 0
                    if self.state == "play":
                        self.fire(min(idx, 1))
                    else:
                        self.advance()

    def advance(self):
        if self.state == "title":
            self.wins = [0, 0]
            self.reset_round()
            self.state = "play"
        elif self.state == "matchover":
            self.state = "title"

    def fire(self, idx):
        if self.state != "play":
            return
        tk = self.tanks[idx]
        if not tk.alive or tk.fire_t > 0:
            return
        mine = [b for b in self.bullets if b["owner"] == idx]
        if len(mine) >= self.t["max_bullets"]:
            return
        a = math.radians(tk.angle)
        bx = tk.x + math.cos(a) * (tk.w * 0.5)
        by = tk.y + math.sin(a) * (tk.w * 0.5)
        self.bullets.append({
            "x": bx, "y": by,
            "vx": math.cos(a) * self.t["bullet_speed"],
            "vy": math.sin(a) * self.t["bullet_speed"],
            "owner": idx, "life": self.t["bullet_life"],
        })
        tk.fire_t = self.t["fire_cooldown"]

    def tank_input(self, tk, idx):
        keys = pygame.key.get_pressed()
        c = tk.controls
        turn = (1 if keys[c["right"]] else 0) - (1 if keys[c["left"]] else 0)
        move = (1 if keys[c["up"]] else 0) - (1 if keys[c["down"]] else 0)
        if idx < len(self.joysticks):
            js = self.joysticks[idx]
            if js.get_numaxes() >= 1:
                ax = js.get_axis(0)
                if abs(ax) > 0.3:
                    turn = ax
            if js.get_numaxes() >= 2:
                ay = js.get_axis(1)
                if abs(ay) > 0.3:
                    move = -ay
        return turn, move

    def update(self, dt):
        self.anim_t += dt
        for ex in self.explosions:
            ex[2] += dt
        self.explosions = [e for e in self.explosions if e[2] < 0.45]

        if self.state != "play":
            return
        if self.round_over_t > 0:
            self.round_over_t -= dt
            if self.round_over_t <= 0:
                if max(self.wins) >= self.t["wins_to_match"]:
                    self.state = "matchover"
                else:
                    self.reset_round()
            return

        for idx, tk in enumerate(self.tanks):
            if not tk.alive:
                continue
            tk.fire_t = max(0.0, tk.fire_t - dt)
            turn, move = self.tank_input(tk, idx)
            tk.angle += turn * self.t["turn_speed"] * dt
            a = math.radians(tk.angle)
            nx = tk.x + math.cos(a) * move * self.t["move_speed"] * dt
            ny = tk.y + math.sin(a) * move * self.t["move_speed"] * dt
            r = pygame.Rect(int(nx - tk.w * 0.35), int(ny - tk.h * 0.35), int(tk.w * 0.7), int(tk.h * 0.7))
            blocked = False
            if not self.bounds.contains(r):
                blocked = True
            for bar in self.barriers:
                if r.colliderect(bar):
                    blocked = True
                    break
            other = self.tanks[1 - idx]
            if other.alive and r.colliderect(other.rect()):
                blocked = True
            if not blocked:
                tk.x, tk.y = nx, ny

        for b in self.bullets:
            b["life"] -= dt
            b["x"] += b["vx"] * dt
            b["y"] += b["vy"] * dt
            if b["x"] < self.bounds.left or b["x"] > self.bounds.right:
                b["vx"] = -b["vx"]
                b["x"] = max(self.bounds.left, min(self.bounds.right, b["x"]))
            if b["y"] < self.bounds.top or b["y"] > self.bounds.bottom:
                b["vy"] = -b["vy"]
                b["y"] = max(self.bounds.top, min(self.bounds.bottom, b["y"]))
            for bar in self.barriers:
                if bar.collidepoint(b["x"], b["y"]):
                    b["life"] = 0
        self.bullets = [b for b in self.bullets if b["life"] > 0]

        for b in list(self.bullets):
            for idx, tk in enumerate(self.tanks):
                if tk.alive and idx != b["owner"] and tk.rect().collidepoint(b["x"], b["y"]):
                    tk.alive = False
                    self.explosions.append([tk.x, tk.y, 0.0])
                    if b in self.bullets:
                        self.bullets.remove(b)
                    self.wins[b["owner"]] += 1
                    self.winner = b["owner"]
                    self.round_over_t = self.t["respawn_delay"]
                    break

    def draw_arena(self):
        self.canvas.fill((46, 52, 44))
        for y in range(0, VIRTUAL_H, 16):
            for x in range(0, VIRTUAL_W, 16):
                if (x // 16 + y // 16) % 2 == 0:
                    self.canvas.fill((50, 56, 48), (x, y, 16, 16))
        m = 14
        wall = (60, 50, 44)
        pygame.draw.rect(self.canvas, wall, (0, 0, VIRTUAL_W, m))
        pygame.draw.rect(self.canvas, wall, (0, VIRTUAL_H - m, VIRTUAL_W, m))
        pygame.draw.rect(self.canvas, wall, (0, 0, m, VIRTUAL_H))
        pygame.draw.rect(self.canvas, wall, (VIRTUAL_W - m, 0, m, VIRTUAL_H))
        pygame.draw.rect(self.canvas, (90, 76, 64), self.bounds, 2)
        for bar in self.barriers:
            self.canvas.blit(self.sprites["barrier"], bar.topleft)

    def draw_tank(self, tk):
        img = pygame.transform.rotate(tk.body, -tk.angle)
        rect = img.get_rect(center=(int(tk.x), int(tk.y)))
        self.canvas.blit(img, rect)

    def draw(self):
        self.draw_arena()
        if self.state == "title":
            title = self.sprites["title"]
            self.canvas.blit(title, (VIRTUAL_W // 2 - title.get_width() // 2, 30))
            self.canvas.blit(self.sprites["tank_red"], (150, 150))
            self.canvas.blit(pygame.transform.flip(self.sprites["tank_blue"], True, False), (322, 150))
            lines = [
                "2 PLAYERS - blast the other tank!",
                "P1: WASD move + L-Shift fire",
                "P2: Arrows move + R-Shift fire",
                f"First to {self.t['wins_to_match']} wins",
                "Press Space to start",
            ]
            for i, ln in enumerate(lines):
                col = (235, 230, 225) if i < 4 else (255, 240, 160)
                t = self.font_small.render(ln, True, col)
                self.canvas.blit(t, (VIRTUAL_W // 2 - t.get_width() // 2, 190 + i * 19))
        else:
            for tk in self.tanks:
                if tk.alive:
                    self.draw_tank(tk)
            for b in self.bullets:
                spr = self.tanks[b["owner"]].bullet
                self.canvas.blit(spr, (int(b["x"] - spr.get_width() / 2), int(b["y"] - spr.get_height() / 2)))
            exp = self.sprites["explosion"]
            for ex in self.explosions:
                fi = min(2, int(ex[2] / 0.15))
                f = exp[fi]
                self.canvas.blit(f, (int(ex[0] - f.get_width() / 2), int(ex[1] - f.get_height() / 2)))
            self.draw_score()
            if self.round_over_t > 0 and self.winner is not None:
                col = self.tanks[self.winner].color
                t = self.font.render(f"P{self.winner + 1} SCORES!", True, col)
                self.canvas.blit(t, (VIRTUAL_W // 2 - t.get_width() // 2, 130))
            if self.state == "matchover":
                col = self.tanks[self.winner].color
                t = self.font_big.render(f"P{self.winner + 1} WINS!", True, col)
                self.canvas.blit(t, (VIRTUAL_W // 2 - t.get_width() // 2, 110))
                h = self.font_small.render("Press Space for title", True, (255, 255, 255))
                self.canvas.blit(h, (VIRTUAL_W // 2 - h.get_width() // 2, 158))
        scaled = pygame.transform.scale(self.canvas, (self.out_w, self.out_h))
        self.screen.fill((0, 0, 0))
        self.screen.blit(scaled, (self.out_x, self.out_y))
        pygame.display.flip()

    def draw_score(self):
        self.canvas.blit(self.sprites["head_red"], (20, 20))
        p1 = self.font.render(str(self.wins[0]), True, (255, 120, 120))
        self.canvas.blit(p1, (44, 18))
        p2 = self.font.render(str(self.wins[1]), True, (140, 180, 255))
        self.canvas.blit(p2, (VIRTUAL_W - 44 - p2.get_width(), 18))
        self.canvas.blit(self.sprites["head_blue"], (VIRTUAL_W - 20 - self.sprites["head_blue"].get_width(), 20))

    def run(self):
        while True:
            dt = min(self.clock.tick(60) / 1000.0, 0.033)
            self.handle_events()
            self.update(dt)
            self.draw()


if __name__ == "__main__":
    Game().run()
