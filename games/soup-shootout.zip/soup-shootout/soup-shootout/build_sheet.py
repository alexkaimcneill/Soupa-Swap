from PIL import Image, ImageDraw, ImageFont, ImageFilter
import numpy as np
import json

SHEET_W, SHEET_H = 512, 360

LAYOUT = {
    "tank_red": {"x": 0, "y": 0, "w": 40, "h": 34},
    "tank_blue": {"x": 50, "y": 0, "w": 40, "h": 34},
    "bullet_red": {"x": 100, "y": 0, "w": 10, "h": 10},
    "bullet_blue": {"x": 120, "y": 0, "w": 10, "h": 10},
    "barrier": {"x": 140, "y": 0, "w": 32, "h": 32},
    "explosion": {"x": 180, "y": 0, "w": 26, "h": 26, "frames": 3, "vertical": True},
    "head_red": {"x": 220, "y": 0, "w": 20, "h": 20},
    "head_blue": {"x": 250, "y": 0, "w": 20, "h": 20},
    "title": {"x": 0, "y": 100, "w": 500, "h": 90},
}

boxes = []
for name, s in LAYOUT.items():
    f = s.get("frames", 1)
    th = s["h"] * f if s.get("vertical") else s["h"]
    boxes.append((name, s["x"], s["y"], s["x"] + s["w"], s["y"] + th))
for i in range(len(boxes)):
    for j in range(i + 1, len(boxes)):
        n1, a, b, c, e = boxes[i]
        n2, f, g, h, k = boxes[j]
        assert not (a < h and f < c and b < k and g < e), f"OVERLAP {n1}/{n2}"
for name, x1, y1, x2, y2 in boxes:
    assert x2 <= SHEET_W and y2 <= SHEET_H, f"OOB {name}"
print("layout verified")

sheet = Image.new("RGBA", (SHEET_W, SHEET_H), (0, 0, 0, 0))
d = ImageDraw.Draw(sheet)

CREAM = (244, 232, 214)
CREAM_D = (216, 198, 172)
BROWN = (120, 92, 76)
MASK = (86, 66, 58)


def tanuki_head(ox, oy, w=20, h=20):
    d.ellipse([ox + 2, oy + 2, ox + w - 2, oy + h - 2], fill=CREAM, outline=MASK)
    d.polygon([(ox + 3, oy + 4), (ox + 1, oy - 2), (ox + 7, oy + 2)], fill=CREAM_D, outline=MASK)
    d.polygon([(ox + w - 3, oy + 4), (ox + w - 1, oy - 2), (ox + w - 7, oy + 2)], fill=BROWN, outline=MASK)
    d.ellipse([ox + 4, oy + 7, ox + 9, oy + 12], fill=MASK)
    d.ellipse([ox + w - 9, oy + 7, ox + w - 4, oy + 12], fill=MASK)
    d.ellipse([ox + 5, oy + 8, ox + 7, oy + 10], fill=(255, 255, 255))
    d.ellipse([ox + w - 8, oy + 8, ox + w - 6, oy + 10], fill=(255, 255, 255))
    d.ellipse([ox + w // 2 - 2, oy + 12, ox + w // 2 + 2, oy + 16], fill=(70, 52, 46))


def draw_tank(ox, oy, body, body_d, trim):
    d.rectangle([ox + 4, oy + 20, ox + 36, oy + 32], fill=body_d, outline=(30, 30, 40))
    for tx in range(ox + 6, ox + 34, 6):
        d.ellipse([tx, oy + 26, tx + 5, oy + 31], fill=(50, 50, 58), outline=(20, 20, 26))
    d.rectangle([ox + 8, oy + 12, ox + 32, oy + 22], fill=body, outline=(30, 30, 40))
    tanuki_head(ox + 10, oy + 2)
    d.rectangle([ox + 18, oy + 8, ox + 38, oy + 12], fill=body_d, outline=(30, 30, 40))
    d.rectangle([ox + 34, oy + 9, ox + 40, oy + 11], fill=trim)


draw_tank(LAYOUT["tank_red"]["x"], LAYOUT["tank_red"]["y"], (222, 70, 70), (176, 44, 48), (255, 210, 90))
draw_tank(LAYOUT["tank_blue"]["x"], LAYOUT["tank_blue"]["y"], (74, 120, 224), (44, 78, 176), (150, 220, 255))

for key, col, ring in [("bullet_red", (255, 180, 90), (180, 60, 40)),
                       ("bullet_blue", (150, 220, 255), (40, 90, 180))]:
    L = LAYOUT[key]
    bx, by = L["x"], L["y"]
    d.ellipse([bx + 1, by + 1, bx + 8, by + 8], fill=col, outline=ring)
    d.ellipse([bx + 3, by + 3, bx + 5, by + 5], fill=(255, 255, 255))

L = LAYOUT["barrier"]
bx, by = L["x"], L["y"]
d.rectangle([bx, by, bx + 31, by + 31], fill=(96, 100, 116), outline=(40, 44, 56))
for rr in range(by + 3, by + 30, 8):
    for cc in range(bx + 3, bx + 30, 8):
        d.rectangle([cc, rr, cc + 5, rr + 5], fill=(120, 124, 140), outline=(70, 74, 88))

L = LAYOUT["explosion"]
exx, exy = L["x"], L["y"]
d.ellipse([exx + 9, exy + 9, exx + 15, exy + 15], fill=(255, 250, 210))
d.ellipse([exx + 5, exy + 31, exx + 19, exy + 45], fill=(255, 200, 90))
d.ellipse([exx + 9, exy + 35, exx + 15, exy + 41], fill=(255, 250, 210))
for dxp, dyp in [(-8, -8), (8, -8), (-8, 8), (8, 8), (0, -10), (0, 10), (-10, 0), (10, 0)]:
    cx2, cy2 = exx + 13 + dxp, exy + 65 + dyp
    d.ellipse([cx2 - 2, cy2 - 2, cx2 + 2, cy2 + 2], fill=(255, 150, 70))
d.ellipse([exx + 8, exy + 60, exx + 18, exy + 70], fill=(255, 220, 120))

tanuki_head(LAYOUT["head_red"]["x"], LAYOUT["head_red"]["y"])
tanuki_head(LAYOUT["head_blue"]["x"], LAYOUT["head_blue"]["y"])

L = LAYOUT["title"]
tx, ty = L["x"], L["y"]
text = "SOUP SHOOTOUT"
font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 15)
tmp = Image.new("L", (10, 10))
bb = ImageDraw.Draw(tmp).textbbox((0, 0), text, font=font)
tw, th = bb[2] - bb[0], bb[3] - bb[1]
low = Image.new("L", (tw + 8, th + 8), 0)
ImageDraw.Draw(low).text((4 - bb[0], 4 - bb[1]), text, font=font, fill=255)
SC = 3
big = low.resize((low.width * SC, low.height * SC), Image.NEAREST)
big_np = (np.array(big) > 120).astype(np.uint8) * 255
mask_img = Image.fromarray(big_np, "L")
outline = mask_img.filter(ImageFilter.MaxFilter(7))
BW, BH = mask_img.size
tc = Image.new("RGBA", (BW, BH), (0, 0, 0, 0))
orr = np.zeros((BH, BW, 4), dtype=np.uint8)
orr[:, :, 0] = 60
orr[:, :, 1] = 20
orr[:, :, 2] = 20
orr[:, :, 3] = np.array(outline)
tc.alpha_composite(Image.fromarray(orr, "RGBA"))
fill = np.zeros((BH, BW, 4), dtype=np.uint8)
top = np.array([255, 210, 90])
bot = np.array([220, 90, 50])
marr = np.array(mask_img)
for y in range(BH):
    t = y / BH
    c = (top * (1 - t) + bot * t).astype(np.uint8)
    fill[y, :, 0] = c[0]
    fill[y, :, 1] = c[1]
    fill[y, :, 2] = c[2]
fill[:, :, 3] = marr
tc.alpha_composite(Image.fromarray(fill, "RGBA"))
bb2 = tc.getbbox()
tc = tc.crop(bb2)
scale = min(L["w"] / tc.width, L["h"] / tc.height) * 0.96
nw, nh = int(tc.width * scale), int(tc.height * scale)
tc = tc.resize((nw, nh), Image.NEAREST)
sheet.alpha_composite(tc, (tx + (L["w"] - nw) // 2, ty + (L["h"] - nh) // 2))

sheet.save("sprites.png")
print("sprites.png built", sheet.size)

config = {
    "sheet": "sprites.png",
    "sprites": LAYOUT,
    "tuning": {
        "move_speed": 95,
        "turn_speed": 150,
        "bullet_speed": 240,
        "fire_cooldown": 0.6,
        "bullet_life": 2.5,
        "max_bullets": 3,
        "wins_to_match": 5,
        "respawn_delay": 1.2,
    },
}
with open("sprites.json", "w") as f:
    json.dump(config, f, indent=2)
print("sprites.json built")

marked = sheet.copy()
md = ImageDraw.Draw(marked)
font_s = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 10)
colors = {
    "tank_red": (255, 100, 100), "tank_blue": (120, 170, 255),
    "bullet_red": (255, 200, 90), "bullet_blue": (150, 220, 255),
    "barrier": (200, 200, 210), "explosion": (255, 170, 40),
    "head_red": (255, 160, 120), "head_blue": (160, 200, 255), "title": (255, 220, 90),
}
for name, s in LAYOUT.items():
    color = colors[name]
    f = s.get("frames", 1)
    if f > 1 and s.get("vertical"):
        for i in range(f):
            yy = s["y"] + i * s["h"]
            md.rectangle([s["x"], yy, s["x"] + s["w"] - 1, yy + s["h"] - 1], outline=color, width=1)
            md.text((s["x"] + 2, yy + 1), f"{name}{i}", font=font_s, fill=color)
    else:
        md.rectangle([s["x"], s["y"], s["x"] + s["w"] - 1, s["y"] + s["h"] - 1], outline=color, width=1)
        md.text((s["x"] + 2, s["y"] + 1), name, font=font_s, fill=color)
marked.save("sprites_marked.png")
print("sprites_marked.png built")

icon = Image.new("RGBA", (256, 256), (0, 0, 0, 0))
ic = ImageDraw.Draw(icon)
for y in range(256):
    t = y / 256
    ic.rectangle([0, y, 256, y + 1], fill=(int(50 + 20 * t), int(46 + 16 * t), int(60 + 24 * t)))
red = sheet.crop((0, 0, 40, 34)).resize((120, 102), Image.NEAREST)
blue = sheet.crop((50, 0, 90, 34)).resize((120, 102), Image.NEAREST).transpose(Image.FLIP_LEFT_RIGHT)
icon.alpha_composite(red, (10, 130))
icon.alpha_composite(blue, (126, 130))
t = LAYOUT["title"]
logo = sheet.crop((t["x"], t["y"], t["x"] + t["w"], t["y"] + t["h"]))
lb = logo.getbbox()
logo = logo.crop(lb)
lw = 234
lh = int(logo.height * lw / logo.width)
icon.alpha_composite(logo.resize((lw, lh), Image.NEAREST), (11, 30))
icon.save("icon.png")
print("icon.png built")
