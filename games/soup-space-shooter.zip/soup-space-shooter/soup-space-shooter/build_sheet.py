from PIL import Image, ImageDraw, ImageFont
import json
import random

SHEET_W, SHEET_H = 512, 560

LAYOUT = {
    "background": {"x": 0, "y": 0, "w": 512, "h": 300},
    "player": {"x": 0, "y": 310, "w": 40, "h": 34},
    "enemy1": {"x": 60, "y": 310, "w": 26, "h": 22, "frames": 2, "vertical": True},
    "enemy2": {"x": 100, "y": 310, "w": 26, "h": 22, "frames": 2, "vertical": True},
    "enemy3": {"x": 140, "y": 310, "w": 28, "h": 24, "frames": 2, "vertical": True},
    "bullet": {"x": 182, "y": 310, "w": 6, "h": 14},
    "ebullet": {"x": 200, "y": 310, "w": 8, "h": 12},
    "explosion": {"x": 220, "y": 310, "w": 22, "h": 22, "frames": 3, "vertical": True},
    "gameover": {"x": 260, "y": 310, "w": 200, "h": 44},
    "mothership": {"x": 410, "y": 360, "w": 74, "h": 52},
    "title": {"x": 0, "y": 420, "w": 400, "h": 130},
}

boxes = []
for name, s in LAYOUT.items():
    frames = s.get("frames", 1)
    total_h = s["h"] * frames if s.get("vertical") else s["h"]
    boxes.append((name, s["x"], s["y"], s["x"] + s["w"], s["y"] + total_h))
for i in range(len(boxes)):
    for j in range(i + 1, len(boxes)):
        n1, a, b, c, e = boxes[i]
        n2, f, g, h, k = boxes[j]
        assert not (a < h and f < c and b < k and g < e), f"OVERLAP {n1}/{n2}"
for name, x1, y1, x2, y2 in boxes:
    assert x2 <= SHEET_W and y2 <= SHEET_H, f"OUT OF BOUNDS {name} ({x2},{y2})"
print("layout verified: no overlaps, all in bounds")

sheet = Image.new("RGBA", (SHEET_W, SHEET_H), (0, 0, 0, 0))
d = ImageDraw.Draw(sheet)

random.seed(7)
d.rectangle([0, 0, 512, 300], fill=(10, 12, 34))
d.rectangle([0, 0, 512, 90], fill=(14, 14, 42))
d.rectangle([0, 90, 512, 180], fill=(12, 13, 38))

for _ in range(140):
    x = random.randint(0, 511)
    y = random.randint(0, 299)
    b = random.choice([(90, 95, 130), (150, 155, 190), (220, 224, 245), (255, 255, 255)])
    d.point((x, y), fill=b)
for _ in range(14):
    x = random.randint(0, 508)
    y = random.randint(0, 296)
    d.rectangle([x, y, x + 1, y + 1], fill=(255, 255, 255))
    d.point((x - 1, y), fill=(160, 165, 200))
    d.point((x + 2, y), fill=(160, 165, 200))

for cx, cy, r, col in [(400, 60, 70, (30, 22, 60)), (120, 220, 60, (20, 30, 62)), (260, 120, 50, (26, 18, 52))]:
    for rr in range(r, 0, -12):
        alpha_col = tuple(min(255, c + (r - rr) // 8) for c in col)
        d.ellipse([cx - rr, cy - rr // 2, cx + rr, cy + rr // 2], fill=alpha_col)
for _ in range(60):
    x = random.randint(0, 511)
    y = random.randint(0, 299)
    d.point((x, y), fill=(200, 205, 235))

pcx, pcy, pr = 430, 230, 40
d.ellipse([pcx - pr, pcy - pr, pcx + pr, pcy + pr], fill=(196, 120, 74))
d.ellipse([pcx - pr + 6, pcy - pr + 6, pcx + pr - 14, pcy + pr - 14], fill=(214, 140, 90))
for band_y, band_h, col in [(-22, 8, (170, 96, 60)), (2, 10, (182, 106, 66)), (24, 6, (160, 90, 58))]:
    d.rectangle([pcx - pr + 4, pcy + band_y, pcx + pr - 4, pcy + band_y + band_h], fill=col)
d.ellipse([pcx - pr, pcy - pr, pcx + pr, pcy + pr], outline=(120, 66, 44))
d.ellipse([pcx - pr - 14, pcy - 8, pcx + pr + 14, pcy + 12], outline=(226, 186, 140), width=3)

mcx, mcy, mr = 80, 60, 16
d.ellipse([mcx - mr, mcy - mr, mcx + mr, mcy + mr], fill=(200, 200, 214))
d.ellipse([mcx - 8, mcy - 6, mcx - 2, mcy], fill=(160, 160, 178))
d.ellipse([mcx + 3, mcy + 4, mcx + 9, mcy + 10], fill=(168, 168, 184))
d.ellipse([mcx + 1, mcy - 11, mcx + 6, mcy - 6], fill=(172, 172, 188))

def px(x, y, c):
    d.point((x, y), fill=c)

L = LAYOUT["player"]
ox, oy = L["x"], L["y"]
HULL = (222, 228, 240)
HULL_D = (168, 178, 200)
HULL_O = (60, 66, 96)
ACC = (255, 150, 60)
GLASS = (140, 214, 250)
GLASS_D = (96, 170, 220)
CREAM = (244, 232, 214)
CREAM_D = (216, 198, 172)
BROWN = (120, 92, 76)
MASK = (86, 66, 58)

d.polygon([(ox + 8, oy + 33), (ox + 13, oy + 16), (ox + 27, oy + 16), (ox + 32, oy + 33)], fill=HULL, outline=HULL_O)
d.polygon([(ox + 0, oy + 33), (ox + 9, oy + 22), (ox + 12, oy + 33)], fill=HULL_D, outline=HULL_O)
d.polygon([(ox + 40, oy + 33), (ox + 31, oy + 22), (ox + 28, oy + 33)], fill=HULL_D, outline=HULL_O)
d.rectangle([ox + 2, oy + 28, ox + 8, oy + 31], fill=ACC)
d.rectangle([ox + 32, oy + 28, ox + 38, oy + 31], fill=ACC)
d.rectangle([ox + 16, oy + 30, ox + 24, oy + 33], fill=HULL_D, outline=HULL_O)
d.rectangle([ox + 17, oy + 31, ox + 19, oy + 33], fill=(255, 200, 90))
d.rectangle([ox + 21, oy + 31, ox + 23, oy + 33], fill=(255, 200, 90))

d.ellipse([ox + 11, oy + 2, ox + 29, oy + 20], fill=GLASS, outline=HULL_O)
d.arc([ox + 11, oy + 2, ox + 29, oy + 20], 180, 300, fill=(220, 245, 255), width=2)

hx, hy = ox + 14, oy + 6
d.ellipse([hx, hy, hx + 12, hy + 11], fill=CREAM, outline=MASK)
d.polygon([(hx + 1, hy + 2), (hx - 1, hy - 2), (hx + 4, hy)], fill=CREAM_D, outline=MASK)
d.polygon([(hx + 11, hy + 2), (hx + 13, hy - 2), (hx + 8, hy)], fill=BROWN, outline=MASK)
d.ellipse([hx + 1, hy + 4, hx + 5, hy + 8], fill=MASK)
d.ellipse([hx + 7, hy + 4, hx + 11, hy + 8], fill=MASK)
px(hx + 3, hy + 5, (255, 255, 255))
px(hx + 9, hy + 5, (255, 255, 255))
d.ellipse([hx + 5, hy + 7, hx + 7, hy + 9], fill=(70, 52, 46))
d.rectangle([ox + 13, oy + 17, ox + 27, oy + 19], fill=GLASS_D)

def enemy1(ox, oy, frame):
    BODY = (120, 220, 140)
    BODY_D = (76, 168, 100)
    O = (30, 70, 44)
    EYE = (255, 240, 120)
    d.ellipse([ox + 3, oy + 6, ox + 23, oy + 18], fill=BODY, outline=O)
    d.ellipse([ox + 7, oy + 2, ox + 19, oy + 12], fill=BODY_D, outline=O)
    d.ellipse([ox + 10, oy + 5, ox + 13, oy + 8], fill=EYE)
    d.ellipse([ox + 14, oy + 5, ox + 17, oy + 8], fill=EYE)
    if frame == 0:
        d.polygon([(ox + 3, oy + 12), (ox - 1 + 1, oy + 20), (ox + 7, oy + 15)], fill=BODY_D, outline=O)
        d.polygon([(ox + 23, oy + 12), (ox + 25, oy + 20), (ox + 19, oy + 15)], fill=BODY_D, outline=O)
    else:
        d.polygon([(ox + 3, oy + 12), (ox + 1, oy + 6), (ox + 7, oy + 11)], fill=BODY_D, outline=O)
        d.polygon([(ox + 23, oy + 12), (ox + 25, oy + 6), (ox + 19, oy + 11)], fill=BODY_D, outline=O)
    d.rectangle([ox + 11, oy + 14, ox + 15, oy + 16], fill=(40, 90, 56))

def enemy2(ox, oy, frame):
    BODY = (170, 140, 255)
    BODY_D = (120, 92, 210)
    O = (58, 40, 110)
    d.polygon([(ox + 13, oy + 1), (ox + 24, oy + 11), (ox + 13, oy + 21), (ox + 2, oy + 11)], fill=BODY, outline=O)
    d.polygon([(ox + 13, oy + 5), (ox + 20, oy + 11), (ox + 13, oy + 17), (ox + 6, oy + 11)], fill=BODY_D, outline=O)
    eye = (255, 120, 160) if frame == 0 else (255, 220, 120)
    d.ellipse([ox + 10, oy + 8, ox + 16, oy + 14], fill=eye, outline=O)
    if frame == 0:
        d.line([(ox + 2, oy + 11), (ox - 1 + 1, oy + 5)], fill=O)
        d.line([(ox + 24, oy + 11), (ox + 26, oy + 5)], fill=O)
    else:
        d.line([(ox + 2, oy + 11), (ox - 1 + 1, oy + 17)], fill=O)
        d.line([(ox + 24, oy + 11), (ox + 26, oy + 17)], fill=O)

def enemy3(ox, oy, frame):
    BODY = (255, 130, 120)
    BODY_D = (210, 80, 80)
    O = (110, 30, 40)
    d.ellipse([ox + 2, oy + 8, ox + 26, oy + 20], fill=BODY, outline=O)
    d.ellipse([ox + 8, oy + 2, ox + 20, oy + 14], fill=BODY_D, outline=O)
    d.rectangle([ox + 10, oy + 6, ox + 12, oy + 9], fill=(255, 240, 200))
    d.rectangle([ox + 16, oy + 6, ox + 18, oy + 9], fill=(255, 240, 200))
    lights = [(ox + 5, oy + 13), (ox + 11, oy + 15), (ox + 17, oy + 15), (ox + 23, oy + 13)]
    for i, (lx, ly) in enumerate(lights):
        on = (i % 2 == frame)
        d.rectangle([lx, ly, lx + 2, ly + 2], fill=(255, 250, 150) if on else (140, 50, 55))
    if frame == 0:
        d.line([(ox + 14, oy + 2), (ox + 14, oy - 1 + 1)], fill=O)
    else:
        d.line([(ox + 14, oy + 2), (ox + 12, oy - 1 + 1)], fill=O)

for f in range(2):
    enemy1(LAYOUT["enemy1"]["x"], LAYOUT["enemy1"]["y"] + f * 22, f)
    enemy2(LAYOUT["enemy2"]["x"], LAYOUT["enemy2"]["y"] + f * 22, f)
    enemy3(LAYOUT["enemy3"]["x"], LAYOUT["enemy3"]["y"] + f * 24, f)

L = LAYOUT["bullet"]
bx, by = L["x"], L["y"]
d.rectangle([bx + 1, by + 2, bx + 4, by + 13], fill=(255, 220, 120))
d.rectangle([bx + 2, by, bx + 3, by + 13], fill=(255, 250, 220))

L = LAYOUT["ebullet"]
ex, ey = L["x"], L["y"]
d.ellipse([ex, ey, ex + 7, ey + 7], fill=(255, 110, 130), outline=(140, 30, 60))
d.rectangle([ex + 2, ey + 7, ex + 5, ey + 11], fill=(255, 170, 180))

L = LAYOUT["explosion"]
exx, exy = L["x"], L["y"]
d.ellipse([exx + 8, exy + 8, exx + 14, exy + 14], fill=(255, 250, 210))
d.ellipse([exx + 5, exy + 27, exx + 17, exy + 39], fill=(255, 200, 90))
d.ellipse([exx + 8, exy + 30, exx + 14, exy + 36], fill=(255, 250, 210))
for ang_dx, ang_dy in [(-7, -7), (7, -7), (-7, 7), (7, 7), (0, -9), (0, 9), (-9, 0), (9, 0)]:
    cx2, cy2 = exx + 11 + ang_dx, exy + 55 + ang_dy
    d.ellipse([cx2 - 2, cy2 - 2, cx2 + 2, cy2 + 2], fill=(255, 150, 70))
d.ellipse([exx + 7, exy + 51, exx + 15, exy + 59], fill=(255, 220, 120))
for sx, sy in [(exx + 2, exy + 46), (exx + 19, exy + 48), (exx + 3, exy + 63), (exx + 18, exy + 64)]:
    d.point((sx, sy), fill=(255, 240, 200))

L = LAYOUT["mothership"]
mx, my = L["x"], L["y"]
mw, mh = L["w"], L["h"]
HULL = (150, 60, 170)
HULL_D = (108, 40, 128)
HULL_L = (190, 100, 210)
TRIM = (255, 210, 90)
GLOW = (120, 255, 220)
d.ellipse([mx + 4, my + 20, mx + mw - 4, my + 44], fill=HULL, outline=(60, 20, 80))
d.ellipse([mx + 4, my + 20, mx + mw - 4, my + 32], fill=HULL_L)
d.ellipse([mx + 18, my + 6, mx + mw - 18, my + 30], fill=HULL_D, outline=(60, 20, 80))
d.ellipse([mx + 26, my + 2, mx + mw - 26, my + 18], fill=(200, 130, 220), outline=(60, 20, 80))
d.ellipse([mx + 32, my + 6, mx + mw - 32, my + 14], fill=GLOW)
for i in range(6):
    lx = mx + 12 + i * 10
    col = TRIM if i % 2 == 0 else GLOW
    d.ellipse([lx, my + 34, lx + 5, my + 39], fill=col)
d.polygon([(mx + mw // 2 - 8, my + 42), (mx + mw // 2 + 8, my + 42),
           (mx + mw // 2 + 4, my + 50), (mx + mw // 2 - 4, my + 50)], fill=(90, 30, 110))
d.ellipse([mx + mw // 2 - 5, my + 46, mx + mw // 2 + 5, my + 52], fill=GLOW)

try:
    font_title = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 44)
    font_sub = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 34)
    font_go = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 26)
except OSError:
    font_title = font_sub = font_go = ImageFont.load_default()

def outlined_text(x, y, text, font, fill, outline, ow=2):
    for dx in range(-ow, ow + 1):
        for dy in range(-ow, ow + 1):
            if dx or dy:
                d.text((x + dx, y + dy), text, font=font, fill=outline)
    d.text((x, y), text, font=font, fill=fill)

L = LAYOUT["gameover"]
outlined_text(L["x"] + 8, L["y"] + 6, "GAME OVER", font_go, (255, 240, 220), (120, 30, 40))

L = LAYOUT["title"]
tx, ty = L["x"], L["y"]
SW_YELLOW = (255, 221, 66)
SW_OUT = (108, 84, 10)
title_img = Image.new("RGBA", (420, 100), (0, 0, 0, 0))
td = ImageDraw.Draw(title_img)
for dx in range(-2, 3):
    for dy in range(-2, 3):
        if dx or dy:
            td.text((10 + dx, 2 + dy), "SOUP", font=font_title, fill=SW_OUT)
            td.text((120 + dx, 48 + dy), "SPACE SHOOTER", font=font_sub, fill=SW_OUT)
td.text((10, 2), "SOUP", font=font_title, fill=SW_YELLOW)
td.text((120, 48), "SPACE SHOOTER", font=font_sub, fill=SW_YELLOW)
title_img = title_img.transform((420, 130), Image.QUAD,
    (30, 0, 390, 0, 420, 100, 0, 100), resample=Image.NEAREST)
title_img = title_img.resize((400, 124), Image.NEAREST)
sheet.alpha_composite(title_img, (tx, ty))

sheet.save("sprites.png")
print("sprites.png built", sheet.size)

config = {
    "sheet": "sprites.png",
    "sprites": LAYOUT,
    "tuning": {
        "player_speed": 190,
        "bullet_speed": 330,
        "fire_cooldown": 0.32,
        "enemy_bullet_speed": 140,
        "formation_speed": 34,
        "formation_speed_per_wave": 8,
        "descend_step": 12,
        "enemy_fire_rate": 0.9,
        "enemy_rows": 4,
        "enemy_cols": 8,
        "lives": 3,
        "animation_fps": 3,
    },
}
with open("sprites.json", "w") as f:
    json.dump(config, f, indent=2)
print("sprites.json built")

marked = sheet.copy()
md = ImageDraw.Draw(marked)
try:
    font_s = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 10)
except OSError:
    font_s = ImageFont.load_default()
colors = {
    "background": (0, 220, 90), "player": (0, 255, 255), "enemy1": (120, 255, 120),
    "enemy2": (190, 150, 255), "enemy3": (255, 140, 130), "bullet": (255, 255, 0),
    "ebullet": (255, 90, 120), "explosion": (255, 170, 40),
    "gameover": (220, 120, 255), "title": (120, 170, 255),
}
for name, s in LAYOUT.items():
    color = colors[name]
    frames = s.get("frames", 1)
    if frames > 1 and s.get("vertical"):
        for i in range(frames):
            yy = s["y"] + i * s["h"]
            md.rectangle([s["x"], yy, s["x"] + s["w"] - 1, yy + s["h"] - 1], outline=color, width=1)
            md.text((s["x"] + 2, yy + 1), f"{name}{i}", font=font_s, fill=color)
    else:
        md.rectangle([s["x"], s["y"], s["x"] + s["w"] - 1, s["y"] + s["h"] - 1], outline=color, width=1)
        md.text((s["x"] + 2, s["y"] + 1), f"{name} {s['x']},{s['y']}", font=font_s, fill=color)
marked.save("sprites_marked.png")
print("sprites_marked.png built")

icon = sheet.crop((0, 0, 300, 300)).resize((256, 256), Image.NEAREST)
p = LAYOUT["player"]
ship = sheet.crop((p["x"], p["y"], p["x"] + p["w"], p["y"] + p["h"])).resize((140, 119), Image.NEAREST)
icon.alpha_composite(ship, (58, 100))
t = LAYOUT["title"]
logo = sheet.crop((t["x"], t["y"], t["x"] + t["w"], t["y"] + t["h"])).resize((240, 78), Image.NEAREST)
icon.alpha_composite(logo, (8, 14))
icon.save("icon.png")
print("icon.png built")
