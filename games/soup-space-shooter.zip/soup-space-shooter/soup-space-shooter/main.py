import os
import sys
import json
import math
import random
import pygame
from name_entry import NameEntry

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
VIRTUAL_W, VIRTUAL_H = 512, 300

CRAWL_LINES = [
    "Episode IV",
    "A NEW SOUP",
    "",
    "It is a period of galactic",
    "hunger. SOUP, a brave tanuki",
    "pilot, races across the stars",
    "in his trusty ship to defend",
    "the last bowl in the galaxy",
    "from waves of snack-crazed",
    "invaders...",
]


def load_config():
    with open(os.path.join(BASE_DIR, "sprites.json")) as f:
        return json.load(f)


def slice_sheet(config):
    sheet = pygame.image.load(os.path.join(BASE_DIR, config["sheet"])).convert_alpha()
    sprites = {}
    for name, s in config["sprites"].items():
        frames = s.get("frames", 1)
        if frames > 1:
            if s.get("vertical"):
                sprites[name] = [
                    sheet.subsurface(pygame.Rect(s["x"], s["y"] + i * s["h"], s["w"], s["h"])).copy()
                    for i in range(frames)
                ]
            else:
                stride = s.get("stride", s["w"])
                sprites[name] = [
                    sheet.subsurface(pygame.Rect(s["x"] + i * stride, s["y"], s["w"], s["h"])).copy()
                    for i in range(frames)
                ]
        else:
            sprites[name] = sheet.subsurface(pygame.Rect(s["x"], s["y"], s["w"], s["h"])).copy()
    return sprites


class Enemy:
    def __init__(self, kind, col, row, frames):
        self.kind = kind
        self.col = col
        self.row = row
        self.frames = frames
        self.alive = True
        self.diving = False
        self.dive_t = 0.0
        self.dive_x = 0.0
        self.dive_y = 0.0

    def size(self):
        return self.frames[0].get_width(), self.frames[0].get_height()


class Game:
    def __init__(self):
        pygame.init()
        pygame.mouse.set_visible(False)
        flags = pygame.FULLSCREEN
        size = (0, 0)
        if os.environ.get("GAME_WINDOWED"):
            flags = 0
            size = (1024, 600)
        self.screen = pygame.display.set_mode(size, flags)
        pygame.display.set_caption("Soup Space Shooter")
        self.sw, self.sh = self.screen.get_size()
        scale = min(self.sw // VIRTUAL_W, self.sh // VIRTUAL_H)
        self.scale = max(1, scale)
        self.out_w = VIRTUAL_W * self.scale
        self.out_h = VIRTUAL_H * self.scale
        self.out_x = (self.sw - self.out_w) // 2
        self.out_y = (self.sh - self.out_h) // 2
        self.canvas = pygame.Surface((VIRTUAL_W, VIRTUAL_H))
        self.clock = pygame.time.Clock()
        self.config = load_config()
        self.sprites = slice_sheet(self.config)
        self.tuning = self.config["tuning"]
        self.font = pygame.font.SysFont("dejavusansmono", 20, bold=True)
        self.font_small = pygame.font.SysFont("dejavusans", 13)
        self.font_crawl = pygame.font.SysFont("dejavusans", 14, bold=True)
        self.scores = self.load_scores()
        self.best = self.scores[0]["score"] if self.scores else 0
        self.name_entry = None
        self.last_name = "SOUP"
        pygame.joystick.init()
        self.joysticks = [pygame.joystick.Joystick(i) for i in range(pygame.joystick.get_count())]
        for js in self.joysticks:
            js.init()
        self.state = "title"
        self.crawl_y = float(VIRTUAL_H)
        self.anim_t = 0.0
        self.bg_scroll = 0.0
        self.reset()

    def load_scores(self):
        try:
            with open(os.path.join(BASE_DIR, "scores.json")) as f:
                data = json.load(f)
            entries = []
            for e in data.get("scores", []):
                if isinstance(e, dict):
                    entries.append({"name": str(e.get("name", "SOUP"))[:8], "score": int(e.get("score", 0))})
                else:
                    entries.append({"name": "SOUP", "score": int(e)})
            entries.sort(key=lambda x: x["score"], reverse=True)
            return entries[:5]
        except (OSError, json.JSONDecodeError, ValueError, TypeError):
            return []

    def qualifies(self, value):
        if value <= 0:
            return False
        if len(self.scores) < 5:
            return True
        return value > self.scores[-1]["score"]

    def commit_score(self, name, value):
        self.scores.append({"name": name, "score": int(value)})
        self.scores.sort(key=lambda x: x["score"], reverse=True)
        self.scores = self.scores[:5]
        self.best = self.scores[0]["score"] if self.scores else 0
        try:
            with open(os.path.join(BASE_DIR, "scores.json"), "w") as f:
                json.dump({"scores": self.scores}, f)
        except OSError:
            pass

    def reset(self):
        self.score = 0
        self.lives = self.tuning["lives"]
        self.wave = 1
        self.player_x = VIRTUAL_W / 2
        self.player_y = VIRTUAL_H - 30
        self.bullets = []
        self.ebullets = []
        self.explosions = []
        self.fire_t = 0.0
        self.invuln = 0.0
        self.mother = None
        self.mother_timer = self.tuning.get("mothership_first_delay", 12.0)
        self.captured = 0.0
        self.spawn_wave()

    def spawn_wave(self):
        self.enemies = []
        rows = self.tuning["enemy_rows"]
        cols = self.tuning["enemy_cols"]
        kinds = ["enemy3", "enemy2", "enemy1", "enemy1"]
        for r in range(rows):
            kind = kinds[r % len(kinds)]
            for c in range(cols):
                self.enemies.append(Enemy(kind, c, r, self.sprites[kind]))
        self.form_x = 0.0
        self.form_dir = 1
        self.form_y = 0.0
        self.ebullets = []

    def formation_pos(self, e):
        w, h = e.size()
        spacing_x = 44
        spacing_y = 30
        total_w = (self.tuning["enemy_cols"] - 1) * spacing_x
        base_x = (VIRTUAL_W - total_w) / 2 + e.col * spacing_x
        base_y = 34 + e.row * spacing_y
        wob = math.sin(self.anim_t * 2 + e.col * 0.6) * 3
        return base_x + self.form_x - w / 2, base_y + self.form_y + wob - h / 2

    def player_rect(self):
        p = self.sprites["player"]
        return pygame.Rect(int(self.player_x - p.get_width() / 2) + 6,
                           int(self.player_y - p.get_height() / 2) + 6,
                           p.get_width() - 12, p.get_height() - 12)

    def fire(self):
        if self.state != "play":
            return
        if self.fire_t <= 0:
            b = self.sprites["bullet"]
            self.bullets.append([self.player_x - b.get_width() / 2, self.player_y - 20])
            self.fire_t = self.tuning["fire_cooldown"]

    def start_or_retry(self):
        if self.name_entry is not None:
            return
        if self.state == "title":
            self.reset()
            self.state = "play"
        elif self.state == "dead":
            self.state = "title"
            self.crawl_y = float(VIRTUAL_H)

    def quit(self):
        pygame.quit()
        sys.exit(0)

    def start_name_entry(self):
        def done(name):
            self.last_name = name
            self.commit_score(name, self.score)
            self.name_entry = None
        self.name_entry = NameEntry(VIRTUAL_W, VIRTUAL_H, self.font, self.font_small,
                                    done, initial=self.last_name)
        self.name_entry.set_scale(self.out_x, self.out_y, self.scale)

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.quit()
                continue
            if self.name_entry is not None:
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    self.quit()
                else:
                    self.name_entry.handle_event(event)
                continue
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.quit()
                elif event.key in (pygame.K_SPACE, pygame.K_RETURN):
                    if self.state == "play":
                        self.fire()
                    else:
                        self.start_or_retry()
            elif event.type == pygame.JOYBUTTONDOWN:
                if event.button in (6, 7, 8, 9):
                    self.quit()
                elif self.state == "play":
                    self.fire()
                else:
                    self.start_or_retry()

    def axis_dir(self):
        keys = pygame.key.get_pressed()
        dx = 0
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            dx -= 1
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            dx += 1
        if keys[pygame.K_SPACE]:
            self.fire()
        for js in self.joysticks:
            if js.get_numaxes() > 0:
                ax = js.get_axis(0)
                if ax < -0.4:
                    dx = -1
                elif ax > 0.4:
                    dx = 1
            if js.get_numhats() > 0:
                hx = js.get_hat(0)[0]
                if hx != 0:
                    dx = hx
            if js.get_numbuttons() > 0 and js.get_button(0):
                self.fire()
        return dx

    def update(self, dt):
        self.anim_t += dt
        self.bg_scroll += 26 * dt
        if self.state == "title":
            self.crawl_y -= 18 * dt
            if self.crawl_y < -len(CRAWL_LINES) * 18 - 40:
                self.crawl_y = float(VIRTUAL_H)
            return
        if self.state == "dead":
            for ex in self.explosions:
                ex[2] += dt
            self.explosions = [e for e in self.explosions if e[2] < 0.45]
            return

        self.fire_t = max(0.0, self.fire_t - dt)
        self.invuln = max(0.0, self.invuln - dt)
        dx = self.axis_dir()
        self.player_x += dx * self.tuning["player_speed"] * dt
        half = self.sprites["player"].get_width() / 2
        self.player_x = max(half, min(VIRTUAL_W - half, self.player_x))

        speed = self.tuning["formation_speed"] + (self.wave - 1) * self.tuning["formation_speed_per_wave"]
        self.form_x += self.form_dir * speed * dt
        alive = [e for e in self.enemies if e.alive and not e.diving]
        if alive:
            xs = [self.formation_pos(e)[0] for e in alive]
            ws = [e.size()[0] for e in alive]
            if min(xs) < 6 and self.form_dir < 0:
                self.form_dir = 1
                self.form_y += self.tuning["descend_step"]
            elif max(x + w for x, w in zip(xs, ws)) > VIRTUAL_W - 6 and self.form_dir > 0:
                self.form_dir = -1
                self.form_y += self.tuning["descend_step"]

        all_alive = [e for e in self.enemies if e.alive]
        if all_alive and random.random() < self.tuning["enemy_fire_rate"] * dt:
            shooter = random.choice(all_alive)
            if shooter.diving:
                sx, sy = shooter.dive_x, shooter.dive_y
            else:
                sx, sy = self.formation_pos(shooter)
            w, h = shooter.size()
            eb = self.sprites["ebullet"]
            self.ebullets.append([sx + w / 2 - eb.get_width() / 2, sy + h])

        if all_alive and random.random() < 0.08 * dt * len(all_alive):
            candidates = [e for e in all_alive if not e.diving]
            if candidates:
                diver = random.choice(candidates)
                diver.diving = True
                diver.dive_t = 0.0
                diver.dive_x, diver.dive_y = self.formation_pos(diver)

        for e in self.enemies:
            if e.alive and e.diving:
                e.dive_t += dt
                e.dive_y += 90 * dt
                e.dive_x += math.sin(e.dive_t * 4) * 60 * dt
                if e.dive_y > VIRTUAL_H + 30:
                    e.diving = False

        for b in self.bullets:
            b[1] -= self.tuning["bullet_speed"] * dt
        self.bullets = [b for b in self.bullets if b[1] > -20]
        for b in self.ebullets:
            b[1] += self.tuning["enemy_bullet_speed"] * dt
        self.ebullets = [b for b in self.ebullets if b[1] < VIRTUAL_H + 20]

        bs = self.sprites["bullet"]
        for b in self.bullets:
            br = pygame.Rect(int(b[0]), int(b[1]), bs.get_width(), bs.get_height())
            for e in self.enemies:
                if not e.alive:
                    continue
                if e.diving:
                    ex, ey = e.dive_x, e.dive_y
                else:
                    ex, ey = self.formation_pos(e)
                w, h = e.size()
                if br.colliderect(pygame.Rect(int(ex), int(ey), w, h)):
                    e.alive = False
                    b[1] = -100
                    self.score += (3 - min(e.row, 2)) * 50 + 50
                    self.explosions.append([ex + w / 2, ey + h / 2, 0.0])
                    break

        pr = self.player_rect()
        ebs = self.sprites["ebullet"]
        if self.invuln <= 0:
            hit = False
            for b in self.ebullets:
                if pr.colliderect(pygame.Rect(int(b[0]), int(b[1]), ebs.get_width(), ebs.get_height())):
                    b[1] = VIRTUAL_H + 100
                    hit = True
                    break
            if not hit:
                for e in self.enemies:
                    if e.alive and e.diving:
                        w, h = e.size()
                        if pr.colliderect(pygame.Rect(int(e.dive_x), int(e.dive_y), w, h)):
                            e.alive = False
                            self.explosions.append([e.dive_x + w / 2, e.dive_y + h / 2, 0.0])
                            hit = True
                            break
            if not hit:
                for e in self.enemies:
                    if e.alive and not e.diving:
                        ex, ey = self.formation_pos(e)
                        if ey + e.size()[1] > self.player_y - 10:
                            hit = True
                            break
            if hit:
                self.lives -= 1
                self.invuln = 1.5
                self.explosions.append([self.player_x, self.player_y, 0.0])
                if self.lives <= 0:
                    self.state = "dead"
                    if self.qualifies(self.score):
                        self.start_name_entry()

        for ex in self.explosions:
            ex[2] += dt
        self.explosions = [e for e in self.explosions if e[2] < 0.45]

        self.update_mothership(dt)

        if not any(e.alive for e in self.enemies):
            self.wave += 1
            self.spawn_wave()

    def update_mothership(self, dt):
        ms = self.sprites["mothership"]
        mw, mh = ms.get_width(), ms.get_height()
        if self.mother is None:
            self.mother_timer -= dt
            if self.mother_timer <= 0:
                self.mother = {
                    "x": random.uniform(mw, VIRTUAL_W - mw),
                    "y": -mh,
                    "dir": random.choice([-1, 1]),
                    "beam": False,
                    "hp": self.tuning.get("mothership_hp", 6),
                }
                self.captured = 0.0
            return

        m = self.mother
        target_y = 40
        if m["y"] < target_y:
            m["y"] += 60 * dt
        else:
            m["x"] += m["dir"] * 40 * dt
            if m["x"] < mw / 2:
                m["dir"] = 1
            elif m["x"] > VIRTUAL_W - mw / 2:
                m["dir"] = -1
            beam_dx = abs(m["x"] - self.player_x)
            m["beam"] = beam_dx < mw * 0.6
            if m["beam"] and self.invuln <= 0:
                self.captured += dt
                pull = (m["x"] - self.player_x) * 1.4 * dt
                self.player_x += pull
                if self.captured > 2.2:
                    self.lives -= 1
                    self.invuln = 1.5
                    self.explosions.append([self.player_x, self.player_y, 0.0])
                    self.captured = 0.0
                    m["beam"] = False
                    if self.lives <= 0:
                        self.state = "dead"
                        if self.qualifies(self.score):
                            self.start_name_entry()
            else:
                self.captured = max(0.0, self.captured - dt)

        bs = self.sprites["bullet"]
        mrect = pygame.Rect(int(m["x"] - mw / 2), int(m["y"]), mw, mh)
        for b in self.bullets:
            br = pygame.Rect(int(b[0]), int(b[1]), bs.get_width(), bs.get_height())
            if br.colliderect(mrect):
                b[1] = -100
                m["hp"] -= 1
                self.explosions.append([b[0], m["y"] + mh / 2, 0.0])
                if m["hp"] <= 0:
                    self.score += 500
                    self.explosions.append([m["x"], m["y"] + mh / 2, 0.0])
                    self.mother = None
                    self.mother_timer = random.uniform(14, 20)
                    break

    def draw_hud(self):
        score_t = self.font.render(str(self.score), True, (255, 255, 255))
        self.canvas.blit(score_t, (VIRTUAL_W // 2 - score_t.get_width() // 2, 4))
        wave_t = self.font_small.render(f"WAVE {self.wave}", True, (180, 190, 230))
        self.canvas.blit(wave_t, (VIRTUAL_W - wave_t.get_width() - 8, 6))
        p = self.sprites["player"]
        mini = pygame.transform.scale(p, (p.get_width() // 2, p.get_height() // 2))
        for i in range(self.lives):
            self.canvas.blit(mini, (6 + i * (mini.get_width() + 4), 4))

    def draw_background(self):
        bg = self.sprites["background"]
        bh = bg.get_height()
        offset = int(self.bg_scroll) % bh
        y = -offset
        while y < VIRTUAL_H:
            self.canvas.blit(bg, (0, y))
            y += bh

    def draw(self):
        self.draw_background()
        if self.state == "title":
            surf = pygame.Surface((VIRTUAL_W, VIRTUAL_H), pygame.SRCALPHA)
            for i, line in enumerate(CRAWL_LINES):
                t = self.font_crawl.render(line, True, (255, 221, 66))
                y = self.crawl_y + i * 18
                if -20 < y < VIRTUAL_H:
                    fade = 255
                    if y < 60:
                        fade = max(0, int(255 * y / 60))
                    t.set_alpha(fade)
                    surf.blit(t, (VIRTUAL_W // 2 - t.get_width() // 2, y))
            self.canvas.blit(surf, (0, 0))
            title = self.sprites["title"]
            tw = int(title.get_width() * 0.9)
            th = int(title.get_height() * 0.9)
            t2 = pygame.transform.scale(title, (tw, th))
            self.canvas.blit(t2, (VIRTUAL_W // 2 - tw // 2, 18))
            ship = self.sprites["player"]
            bob = math.sin(self.anim_t * 2) * 4
            self.canvas.blit(ship, (VIRTUAL_W // 2 - ship.get_width() // 2, 210 + bob))
            hint = self.font_small.render("Press A / Space to start", True, (255, 255, 255))
            if int(self.anim_t * 2) % 2 == 0:
                self.canvas.blit(hint, (VIRTUAL_W // 2 - hint.get_width() // 2, 258))
        else:
            frame_i = int(self.anim_t * self.tuning["animation_fps"]) % 2
            if self.mother is not None:
                m = self.mother
                ms = self.sprites["mothership"]
                mw, mh = ms.get_width(), ms.get_height()
                if m["beam"]:
                    beam = pygame.Surface((VIRTUAL_W, VIRTUAL_H), pygame.SRCALPHA)
                    top_w = mw * 0.5
                    bot_w = mw * 1.1
                    bx = m["x"]
                    by = m["y"] + mh
                    pulse = 90 + int(50 * math.sin(self.anim_t * 12))
                    pts = [(bx - top_w / 2, by), (bx + top_w / 2, by),
                           (bx + bot_w / 2, self.player_y + 10), (bx - bot_w / 2, self.player_y + 10)]
                    pygame.draw.polygon(beam, (120, 255, 220, pulse), pts)
                    for i in range(4):
                        ly = by + (self.player_y + 10 - by) * (i + (self.anim_t * 2 % 1)) / 4
                        pygame.draw.line(beam, (200, 255, 240, 160),
                                         (bx - top_w / 2, ly), (bx + top_w / 2, ly), 1)
                    self.canvas.blit(beam, (0, 0))
                self.canvas.blit(ms, (int(m["x"] - mw / 2), int(m["y"])))
            for e in self.enemies:
                if not e.alive:
                    continue
                if e.diving:
                    ex, ey = e.dive_x, e.dive_y
                else:
                    ex, ey = self.formation_pos(e)
                self.canvas.blit(e.frames[frame_i], (int(ex), int(ey)))
            bs = self.sprites["bullet"]
            for b in self.bullets:
                self.canvas.blit(bs, (int(b[0]), int(b[1])))
            ebs = self.sprites["ebullet"]
            for b in self.ebullets:
                self.canvas.blit(ebs, (int(b[0]), int(b[1])))
            exp = self.sprites["explosion"]
            for ex in self.explosions:
                fi = min(2, int(ex[2] / 0.15))
                f = exp[fi]
                self.canvas.blit(f, (int(ex[0] - f.get_width() / 2), int(ex[1] - f.get_height() / 2)))
            if self.state == "play" or self.invuln > 0:
                if self.invuln <= 0 or int(self.anim_t * 10) % 2 == 0:
                    p = self.sprites["player"]
                    self.canvas.blit(p, (int(self.player_x - p.get_width() / 2),
                                         int(self.player_y - p.get_height() / 2)))
            self.draw_hud()
            if self.state == "dead":
                go = self.sprites["gameover"]
                self.canvas.blit(go, (VIRTUAL_W // 2 - go.get_width() // 2, 60))
                score_t = self.font.render(f"{self.score}", True, (255, 255, 255))
                self.canvas.blit(score_t, (VIRTUAL_W // 2 - score_t.get_width() // 2, 108))
                header = self.font_small.render("- HIGH SCORES -", True, (255, 220, 120))
                self.canvas.blit(header, (VIRTUAL_W // 2 - header.get_width() // 2, 140))
                for i, e in enumerate(self.scores[:5]):
                    is_new = (e["score"] == self.score and e["name"] == self.last_name)
                    color = (255, 255, 160) if is_new else (235, 240, 250)
                    name = e["name"][:8].ljust(8)
                    row = self.font_small.render(f"{i + 1}. {name} {e['score']}", True, color)
                    self.canvas.blit(row, (VIRTUAL_W // 2 - row.get_width() // 2, 158 + i * 15))
                if self.name_entry is None:
                    hint = self.font_small.render("Press A / Space for title", True, (255, 255, 255))
                    self.canvas.blit(hint, (VIRTUAL_W // 2 - hint.get_width() // 2, 240))
        if self.name_entry is not None:
            self.name_entry.draw(self.canvas, accent=(120, 90, 210))
        scaled = pygame.transform.scale(self.canvas, (self.out_w, self.out_h))
        self.screen.fill((0, 0, 0))
        self.screen.blit(scaled, (self.out_x, self.out_y))
        pygame.display.flip()

    def run(self):
        while True:
            dt = min(self.clock.tick(60) / 1000.0, 0.05)
            self.handle_events()
            self.update(dt)
            self.draw()


if __name__ == "__main__":
    Game().run()
