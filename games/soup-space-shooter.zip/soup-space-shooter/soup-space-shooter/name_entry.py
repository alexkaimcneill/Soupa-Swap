import pygame

ROWS = [
    "ABCDEFG",
    "HIJKLMN",
    "OPQRSTU",
    "VWXYZ_ ",
]
MAX_LEN = 8


class NameEntry:
    def __init__(self, vw, vh, font, font_small, on_done, initial=""):
        self.vw = vw
        self.vh = vh
        self.font = font
        self.font_small = font_small
        self.on_done = on_done
        self.name = initial[:MAX_LEN]
        self.sel_r = 0
        self.sel_c = 0
        self.repeat_t = 0.0
        self.build_layout()

    def build_layout(self):
        self.keys = []
        cols = max(len(r) for r in ROWS)
        kw = 42
        kh = 34
        gap = 6
        grid_w = cols * kw + (cols - 1) * gap
        start_x = (self.vw - grid_w) // 2
        start_y = 118
        for ri, row in enumerate(ROWS):
            for ci, ch in enumerate(row):
                x = start_x + ci * (kw + gap)
                y = start_y + ri * (kh + gap)
                self.keys.append({"ch": ch, "rect": pygame.Rect(x, y, kw, kh), "r": ri, "c": ci})
        base_y = start_y + len(ROWS) * (kh + gap) + 8
        self.del_rect = pygame.Rect(self.vw // 2 - 96, base_y, 88, 34)
        self.ok_rect = pygame.Rect(self.vw // 2 + 8, base_y, 88, 34)

    def add_char(self, ch):
        if ch == "_":
            ch = " "
        if len(self.name) < MAX_LEN:
            self.name += ch

    def backspace(self):
        self.name = self.name[:-1]

    def confirm(self):
        final = self.name.strip() or "SOUP"
        self.on_done(final)

    def char_at(self, r, c):
        row = ROWS[r]
        if c < len(row):
            return row[c]
        return None

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            mx, my = self.scale_mouse(event.pos)
            for k in self.keys:
                if k["rect"].collidepoint(mx, my):
                    self.add_char(k["ch"])
                    return
            if self.del_rect.collidepoint(mx, my):
                self.backspace()
            elif self.ok_rect.collidepoint(mx, my):
                self.confirm()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_BACKSPACE:
                self.backspace()
            elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                self.confirm()
            elif event.key == pygame.K_LEFT:
                self.sel_c = max(0, self.sel_c - 1)
            elif event.key == pygame.K_RIGHT:
                self.sel_c = min(len(ROWS[self.sel_r]) - 1, self.sel_c + 1)
            elif event.key == pygame.K_UP:
                self.sel_r = max(0, self.sel_r - 1)
                self.sel_c = min(self.sel_c, len(ROWS[self.sel_r]) - 1)
            elif event.key == pygame.K_DOWN:
                self.sel_r = min(len(ROWS) - 1, self.sel_r + 1)
                self.sel_c = min(self.sel_c, len(ROWS[self.sel_r]) - 1)
            elif event.key == pygame.K_SPACE:
                ch = self.char_at(self.sel_r, self.sel_c)
                if ch:
                    self.add_char(ch)
            elif event.unicode and event.unicode.isalnum():
                self.add_char(event.unicode.upper())
        elif event.type == pygame.JOYBUTTONDOWN:
            if event.button == 0:
                ch = self.char_at(self.sel_r, self.sel_c)
                if ch:
                    self.add_char(ch)
            elif event.button == 1:
                self.backspace()
            elif event.button in (2, 3, 9):
                self.confirm()
        elif event.type == pygame.JOYHATMOTION:
            hx, hy = event.value
            if hx < 0:
                self.sel_c = max(0, self.sel_c - 1)
            elif hx > 0:
                self.sel_c = min(len(ROWS[self.sel_r]) - 1, self.sel_c + 1)
            if hy > 0:
                self.sel_r = max(0, self.sel_r - 1)
            elif hy < 0:
                self.sel_r = min(len(ROWS) - 1, self.sel_r + 1)
            self.sel_c = min(self.sel_c, len(ROWS[self.sel_r]) - 1)

    def set_scale(self, out_x, out_y, scale):
        self.out_x = out_x
        self.out_y = out_y
        self.scale = scale

    def scale_mouse(self, pos):
        mx = (pos[0] - getattr(self, "out_x", 0)) / getattr(self, "scale", 1)
        my = (pos[1] - getattr(self, "out_y", 0)) / getattr(self, "scale", 1)
        return mx, my

    def draw(self, canvas, accent=(0, 195, 227)):
        overlay = pygame.Surface((self.vw, self.vh), pygame.SRCALPHA)
        overlay.fill((10, 14, 30, 205))
        canvas.blit(overlay, (0, 0))

        prompt = self.font_small.render("ENTER YOUR NAME", True, (255, 220, 120))
        canvas.blit(prompt, (self.vw // 2 - prompt.get_width() // 2, 40))

        shown = self.name + ("_" if len(self.name) < MAX_LEN else "")
        name_s = self.font.render(shown, True, (255, 255, 255))
        canvas.blit(name_s, (self.vw // 2 - name_s.get_width() // 2, 70))

        for k in self.keys:
            r = k["rect"]
            selected = (k["r"] == self.sel_r and k["c"] == self.sel_c)
            bg = accent if selected else (40, 48, 74)
            pygame.draw.rect(canvas, bg, r, border_radius=5)
            pygame.draw.rect(canvas, (90, 100, 130), r, 1, border_radius=5)
            label = "SP" if k["ch"] == " " else k["ch"]
            ch_s = self.font_small.render(label, True, (255, 255, 255))
            canvas.blit(ch_s, ch_s.get_rect(center=r.center))

        pygame.draw.rect(canvas, (120, 60, 60), self.del_rect, border_radius=5)
        del_s = self.font_small.render("DEL", True, (255, 255, 255))
        canvas.blit(del_s, del_s.get_rect(center=self.del_rect.center))

        pygame.draw.rect(canvas, (50, 130, 70), self.ok_rect, border_radius=5)
        ok_s = self.font_small.render("OK", True, (255, 255, 255))
        canvas.blit(ok_s, ok_s.get_rect(center=self.ok_rect.center))

        hint = self.font_small.render("Tap letters, or use arrows + A", True, (190, 200, 220))
        canvas.blit(hint, (self.vw // 2 - hint.get_width() // 2, self.vh - 20))
