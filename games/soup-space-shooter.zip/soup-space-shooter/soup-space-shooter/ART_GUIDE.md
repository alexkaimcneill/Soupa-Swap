# Editing the Art in Soup Space Shooter

Same system as Flappy Soup: all art in `sprites.png` (512x560), all positions in `sprites.json`, no code editing needed. Open `sprites_marked.png` for the box map.

## The spritesheet layout

| Sprite | Position (x, y) | Size (w x h) | Notes |
|---|---|---|---|
| background | 0, 0 | 512 x 300 | Deep space: stars, nebulas, planet, moon. Fills the screen. |
| player | 0, 310 | 40 x 34 | Soup the tanuki in his ship. One frame. |
| enemy1 frame 0/1 | 60, 310 / 60, 332 | 26 x 22 | Green flapper alien, 2 frames stacked vertically |
| enemy2 frame 0/1 | 100, 310 / 100, 332 | 26 x 22 | Purple diamond alien, 2 frames stacked vertically |
| enemy3 frame 0/1 | 140, 310 / 140, 334 | 28 x 24 | Red saucer (top row, worth more points), 2 frames |
| bullet | 182, 310 | 6 x 14 | Your shot, travels up |
| ebullet | 200, 310 | 8 x 12 | Enemy shot, travels down |
| explosion frames 0/1/2 | 220, 310 / 332 / 354 | 22 x 22 | Small burst, grows over 3 frames |
| gameover | 260, 310 | 200 x 44 | Shown when you die |
| title | 0, 420 | 400 x 130 | Star Wars style slanted yellow logo |

## How to reskin

1. Open `sprites.png` in any pixel editor
2. Use `sprites_marked.png` as your map
3. Draw over any sprite inside its box, save, relaunch

The game renders at 512x300 internally, scaled 2x with hard pixels to 1024x600.

## Gameplay tuning (sprites.json)

- `player_speed` - how fast Soup strafes
- `bullet_speed` / `enemy_bullet_speed` - projectile speeds
- `fire_cooldown` - seconds between your shots (lower = faster firing)
- `formation_speed` - how fast the enemy grid marches
- `formation_speed_per_wave` - added speed each wave
- `descend_step` - how far the grid drops when it hits a wall
- `enemy_fire_rate` - average enemy shots per second
- `enemy_rows` / `enemy_cols` - formation size
- `lives` - starting lives
- `animation_fps` - enemy wing-flap speed

## Testing on a desktop

GAME_WINDOWED=1 python3 main.py  (windowed 1024x600, ESC quits)
On Windows: set GAME_WINDOWED=1, then py -3.12 main.py

## Regenerating default art

python3 build_sheet.py rebuilds sprites.png, sprites.json, sprites_marked.png, icon.png.

## Mothership (added)

A purple tractor-beam mothership descends periodically. Its sprite is at (410, 360), 74x52. When it lines up above Soup it fires a green beam that pulls the ship toward it — stay out from under it or shake free by moving. Shoot it (default 6 hits) for 500 points before it captures you. Tuning keys:
- `mothership_first_delay` - seconds before the first mothership appears
- `mothership_hp` - hits to destroy it

## Leaderboard (added)

Top 5 high scores are saved to `scores.json` in this folder and persist across sessions. They appear on the game-over screen with your latest score highlighted. Delete `scores.json` to reset.
