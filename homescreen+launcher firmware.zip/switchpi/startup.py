import os
import time
import pygame

STARTUP_DIR = os.path.dirname(os.path.abspath(__file__))
LOGO_PATH = os.path.join(STARTUP_DIR, "splash.png")
SOUND_PATH = os.path.join(STARTUP_DIR, "startup.wav")

TEXT_COLOR = (45, 45, 45)


def play_startup(screen, w, h):
    clock = pygame.time.Clock()
    font_large = pygame.font.SysFont("dejavusans", 64, bold=True)
    font_small = pygame.font.SysFont("dejavusans", 24)

    has_logo = os.path.isfile(LOGO_PATH)
    has_sound = os.path.isfile(SOUND_PATH)

    if has_sound:
        try:
            sound = pygame.mixer.Sound(SOUND_PATH)
            sound.play()
        except pygame.error:
            has_sound = False

    start = time.time()
    duration = 3.5 if has_logo else 2.0

    if has_logo:
        logo = pygame.image.load(LOGO_PATH).convert_alpha()
        max_size = min(w, h) // 2
        if logo.get_width() > max_size or logo.get_height() > max_size:
            logo = pygame.transform.smoothscale(logo, (max_size, max_size))
    else:
        logo = None

    while True:
        dt = clock.tick(60) / 1000.0
        elapsed = time.time() - start

        if elapsed >= duration:
            break

        alpha_in = min(1.0, elapsed / 0.6)
        if elapsed > duration - 0.6:
            alpha_in = max(0.0, (duration - elapsed) / 0.6)

        screen.fill((245, 245, 245))

        if logo:
            logo_alpha = logo.copy()
            logo_alpha.set_alpha(int(255 * alpha_in))
            rect = logo_alpha.get_rect(center=(w // 2, h // 2 - 60))
            screen.blit(logo_alpha, rect)
        else:
            title = font_large.render("Home", True, TEXT_COLOR)
            title.set_alpha(int(255 * alpha_in))
            title_rect = title.get_rect(center=(w // 2, h // 2))
            screen.blit(title, title_rect)

        loading = font_small.render("Booting...", True, TEXT_COLOR)
        loading.set_alpha(int(200 * alpha_in))
        loading_rect = loading.get_rect(center=(w // 2, h // 2 + 100))
        screen.blit(loading, loading_rect)

        pygame.display.flip()
