# SwitchPi: Nintendo Switch Style Game Launcher

A fullscreen Pygame-based launcher for Raspberry Pi that boots directly into a Switch-like home menu.

## Features

- **Switch-like UI**: Smooth horizontal scrolling tile grid, clock, signal indicator
- **Drop-in game support**: Add games by creating folders with `game.json`
- **Startup screen**: Optional boot animation with splash image and sound
- **Controller & keyboard**: Full d-pad/analog/button support, hotplug enabled
- **Live reload**: Press F5 or add games without rebooting

## Quick Install

```bash
cd switchpi
bash install.sh
sudo reboot
```

The launcher boots on startup. Add games to the `games/` folder and they appear automatically.

## Adding Games

Create a folder in `games/` with a `game.json` file:

```json
{
  "title": "Pokemon Fire Red",
  "command": "mgba /home/pi/roms/firered.gba",
  "icon": "icon.png"
}
```

- `title`: Display name
- `command`: Shell command to run (Python script, emulator, binary, etc.)
- `icon`: Optional PNG file (square, any size — auto-scaled). If missing, a colored placeholder is generated.

Example structure:
```
games/
  example/
    game.json
    icon.png
  fire-red/
    game.json
    icon.png
  my-custom-game/
    game.json
    icon.png
    main.py
```

Games are scanned on boot and after every F5 press. No service restart needed.

## Customizing the Startup Screen

Place these optional files in the main `switchpi/` directory:

- **splash.png**: Any image (will auto-fit to screen). Fades in and out over 3.5 seconds.
- **startup.wav**: A sound file (plays at boot). Any length — audio plays alongside the splash.

Example:
```bash
# Add a custom logo
cp my_logo.png switchpi/splash.png

# Add a startup beep
cp startup_sound.wav switchpi/startup.wav
```

If `splash.png` is not found, a default "Home" text screen appears instead. Startup sound is entirely optional.

## Controls

| Input | Action |
|-------|--------|
| D-pad / Left Stick | Navigate |
| A / Button 0 | Launch |
| F5 | Rescan games (keyboard only) |
| ESC | Quit (desktop/windowed mode only) |

## Development / Testing

Run in windowed mode on a desktop:

```bash
LAUNCHER_WINDOWED=1 python3 launcher.py
```

Opens a 1280×720 window. Press ESC to exit.

## System Details

- **OS**: Raspberry Pi OS Lite (Bookworm or later)
- **Python**: 3.11+
- **Dependencies**: pygame
- **Boot**: Runs as systemd service (before any desktop)
- **Display**: Full-screen via KMS (no X11 needed)

## Troubleshooting

**Black screen on boot**: Check service status:
```bash
sudo systemctl status launcher.service
sudo journalctl -u launcher.service -n 20
```

**Games don't appear**: Ensure `game.json` exists in each game folder and is valid JSON.

**No audio from startup sound**: Ensure ALSA/PulseAudio is configured (usually automatic on Pi OS).

**Controller not detected**: Unplug and replug. The launcher detects hotplug events.

## Customizing the UI

Edit `launcher.py`:
- **Colors**: Change `BG`, `TILE_BG`, `ACCENT`, etc. at the top
- **Tile size**: Adjust `TILE_SIZE` and `TILE_GAP`
- **Fonts**: Modify `init_display()` font settings
- **Animation speed**: Tweak the `12` in `self.scroll_x += (target - self.scroll_x) * min(1.0, dt * 12)`
