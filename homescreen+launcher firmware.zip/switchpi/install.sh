#!/bin/bash
set -e
sudo apt update
sudo apt install -y python3-pygame
DIR="$(cd "$(dirname "$0")" && pwd)"
sudo tee /etc/systemd/system/launcher.service > /dev/null << UNIT
[Unit]
Description=Switch style game launcher
After=multi-user.target

[Service]
User=$USER
WorkingDirectory=$DIR
ExecStart=/usr/bin/python3 $DIR/launcher.py
Restart=on-failure
Environment=SDL_VIDEODRIVER=kmsdrm

[Install]
WantedBy=multi-user.target
UNIT
sudo systemctl daemon-reload
sudo systemctl enable launcher.service
echo "Installed. Reboot to boot straight into the launcher."
echo ""
echo "Optional: Add a custom splash screen:"
echo "  Place splash.png (any size) in $DIR/"
echo "  Place startup.wav (optional beep) in $DIR/"
