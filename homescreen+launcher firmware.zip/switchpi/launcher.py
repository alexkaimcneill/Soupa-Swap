import os
import sys
import json
import time
import shlex
import subprocess
import pygame

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
GAMES_DIR = os.path.join(BASE_DIR, "games")

BG = (235, 235, 235)
BG_DARK = (45, 45, 45)
TILE_BG = (255, 255, 255)
TILE_SHADOW = (200, 200, 200)
ACCENT = (0, 195, 227)
TEXT = (45, 45, 45)
TEXT_LIGHT = (130, 130, 130)
FOOTER_LINE = (205, 205, 205)

TILE_SIZE = 240
TILE_GAP = 24
SELECT_GROW = 18
FPS = 60


def load_games():
    games = []
    if not os.path.isdir(GAMES_DIR):
        os.makedirs(GAMES_DIR, exist_ok=True)
    for name in sorted(os.listdir(GAMES_DIR)):
        folder = os.path.join(GAMES_DIR, name)
        meta_path = os.path.join(folder, "game.json")
        if not os.path.isfile(meta_path):
            continue
        try:
            with open(meta_path) as f:
                meta = json.load(f)
        except (json.JSONDecodeError, OSError):
            continue
        title = meta.get("title", name)
        command = meta.get("command")
        if not command:
            continue
        icon_path = os.path.join(folder, meta.get("icon", "icon.png"))
        games.append({
            "title": title,
            "command": command,
            "cwd": folder,
            "icon_path": icon_path if os.path.isfile(icon_path) else None,
        })
    return games


def make_placeholder_icon(title, size):
    palette = [
        (230, 0, 18), (0, 195, 227), (255, 153, 0),
        (120, 80, 200), (0, 170, 90), (250, 90, 140),
    ]
    color = palette[sum(ord(c) for c in title) % len(palette)]
    surf = pygame.Surface((size, size))
    surf.fill(color)
    font = pygame.font.SysFont(None, size // 2)
    letter = font.render(title[:1].upper(), True, (255, 255, 255))
    rect = letter.get_rect(center=(size // 2, size // 2))
    surf.blit(letter, rect)
    return surf


def load_icon(game, size):
    if game["icon_path"]:
        try:
            img = pygame.image.load(game["icon_path"]).convert_alpha()
            return pygame.transform.smoothscale(img, (size, size))
        except pygame.error:
            pass
    return make_placeholder_icon(game["title"], size)


def draw_rounded(surface, color, rect, radius):
    pygame.draw.rect(surface, color, rect, border_radius=radius)


def run_game(game):
    pygame.display.quit()
    try:
        subprocess.run(shlex.split(game["command"]), cwd=game["cwd"])
    except (OSError, subprocess.SubprocessError):
        pass


class Launcher:
    def __init__(self):
        pygame.init()
        pygame.mouse.set_visible(False)
        self.init_display()
        self.clock = pygame.time.Clock()
        self.selected = 0
        self.scroll_x = 0.0
        self.reload()
        self.init_joysticks()
        self.axis_cooldown = 0.0

    def init_display(self):
        info = pygame.display.Info()
        self.w, self.h = info.current_w, info.current_h
        flags = pygame.FULLSCREEN
        if os.environ.get("LAUNCHER_WINDOWED"):
            self.w, self.h = 1280, 720
            flags = 0
        self.screen = pygame.display.set_mode((self.w, self.h), flags)
        pygame.display.set_caption("Home")
        self.font_title = pygame.font.SysFont("dejavusans", 42)
        self.font_med = pygame.font.SysFont("dejavusans", 28)
        self.font_small = pygame.font.SysFont("dejavusans", 22)

    def init_joysticks(self):
        pygame.joystick.init()
        self.joysticks = []
        for i in range(pygame.joystick.get_count()):
            js = pygame.joystick.Joystick(i)
            js.init()
            self.joysticks.append(js)

    def reload(self):
        self.games = load_games()
        self.icons = [load_icon(g, TILE_SIZE) for g in self.games]
        self.selected = min(self.selected, max(len(self.games) - 1, 0))

    def move(self, delta):
        if not self.games:
            return
        self.selected = max(0, min(len(self.games) - 1, self.selected + delta))

    def launch_selected(self):
        if not self.games:
            return
        game = self.games[self.selected]
        run_game(game)
        self.init_display()
        self.init_joysticks()
        self.reload()

    def handle_events(self, dt):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.quit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    self.move(-1)
                elif event.key == pygame.K_RIGHT:
                    self.move(1)
                elif event.key in (pygame.K_RETURN, pygame.K_SPACE):
                    self.launch_selected()
                elif event.key == pygame.K_F5:
                    self.reload()
                elif event.key == pygame.K_ESCAPE and os.environ.get("LAUNCHER_WINDOWED"):
                    self.quit()
            elif event.type == pygame.JOYBUTTONDOWN:
                if event.button == 0:
                    self.launch_selected()
            elif event.type == pygame.JOYHATMOTION:
                if event.value[0] < 0:
                    self.move(-1)
                elif event.value[0] > 0:
                    self.move(1)
            elif event.type in (pygame.JOYDEVICEADDED, pygame.JOYDEVICEREMOVED):
                self.init_joysticks()

        self.axis_cooldown = max(0.0, self.axis_cooldown - dt)
        if self.axis_cooldown == 0.0:
            for js in self.joysticks:
                if js.get_numaxes() > 0:
                    ax = js.get_axis(0)
                    if ax < -0.5:
                        self.move(-1)
                        self.axis_cooldown = 0.22
                    elif ax > 0.5:
                        self.move(1)
                        self.axis_cooldown = 0.22

    def quit(self):
        pygame.quit()
        sys.exit(0)

    def draw_top_bar(self):
        pygame.draw.circle(self.screen, ACCENT, (70, 60), 28)
        pygame.draw.circle(self.screen, TILE_BG, (70, 60), 28, 3)
        clock_text = self.font_med.render(time.strftime("%H:%M"), True, TEXT)
        self.screen.blit(clock_text, (self.w - clock_text.get_width() - 130, 46))
        pygame.draw.rect(self.screen, TEXT, (self.w - 100, 50, 44, 22), 2, border_radius=4)
        pygame.draw.rect(self.screen, TEXT, (self.w - 54, 56, 5, 10))
        pygame.draw.rect(self.screen, TEXT, (self.w - 97, 53, 38, 16))

    def draw_footer(self):
        y = self.h - 70
        pygame.draw.line(self.screen, FOOTER_LINE, (60, y), (self.w - 60, y), 2)
        hints = [("A", "OK"), ("F5", "Refresh")]
        x = self.w - 60
        for key, label in reversed(hints):
            label_s = self.font_small.render(label, True, TEXT)
            x -= label_s.get_width()
            self.screen.blit(label_s, (x, y + 18))
            x -= 40
            pygame.draw.circle(self.screen, TEXT, (x + 14, y + 29), 14, 2)
            key_s = self.font_small.render(key, True, TEXT)
            self.screen.blit(key_s, key_s.get_rect(center=(x + 14, y + 29)))
            x -= 40

    def draw_tiles(self, dt):
        cy = self.h // 2
        if not self.games:
            msg = self.font_med.render("No games found", True, TEXT_LIGHT)
            sub = self.font_small.render("Add a folder with game.json inside games/", True, TEXT_LIGHT)
            self.screen.blit(msg, msg.get_rect(center=(self.w // 2, cy - 20)))
            self.screen.blit(sub, sub.get_rect(center=(self.w // 2, cy + 24)))
            return

        target = self.selected * (TILE_SIZE + TILE_GAP)
        self.scroll_x += (target - self.scroll_x) * min(1.0, dt * 12)
        start_x = self.w // 2 - TILE_SIZE // 2 - self.scroll_x

        title = self.games[self.selected]["title"]
        title_s = self.font_title.render(title, True, TEXT)
        self.screen.blit(title_s, (self.w // 2 - title_s.get_width() // 2, cy - TILE_SIZE // 2 - 90))

        for i, game in enumerate(self.games):
            x = start_x + i * (TILE_SIZE + TILE_GAP)
            if x + TILE_SIZE < -50 or x > self.w + 50:
                continue
            size = TILE_SIZE
            y = cy - size // 2
            rect = pygame.Rect(x, y, size, size)
            if i == self.selected:
                grow = SELECT_GROW
                rect = rect.inflate(grow, grow)
                pygame.draw.rect(self.screen, ACCENT, rect.inflate(14, 14), 5, border_radius=18)
            draw_rounded(self.screen, TILE_SHADOW, rect.move(0, 6), 12)
            draw_rounded(self.screen, TILE_BG, rect, 12)
            icon = self.icons[i]
            if rect.width != TILE_SIZE:
                icon = pygame.transform.smoothscale(icon, (rect.width, rect.height))
            mask = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
            draw_rounded(mask, (255, 255, 255, 255), mask.get_rect(), 12)
            tile = icon.copy()
            tile.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
            self.screen.blit(tile, rect.topleft)

    def run(self):
        from startup import play_startup
        play_startup(self.screen, self.w, self.h)
        while True:
            dt = self.clock.tick(FPS) / 1000.0
            self.handle_events(dt)
            self.screen.fill(BG)
            self.draw_top_bar()
            self.draw_tiles(dt)
            self.draw_footer()
            pygame.display.flip()


if __name__ == "__main__":
    Launcher().run()
